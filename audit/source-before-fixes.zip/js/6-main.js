// Gắn các hàm root level
app.startSession = async function () {
    console.log("🔓 Access Granted: Loading Data...");
    await this.storage.load();

    // Sắp xếp lại toàn bộ dữ liệu giao dịch cũ
    if (this.data && this.data.transactions) {
        this.data.transactions.sort(
            (a, b) => app.logic.compareTransactions(a, b)
        );
    }

    //if (this.logic.purgeOldData) this.logic.purgeOldData();
    if (this.logic.fixAllTags) this.logic.fixAllTags();
    this.logic.checkAndRolloverZaloCycle();
    this.logic.processPriorityRefund();
    this.logic.updateFees();
    this.ui.renderAll();

    if (app.effects) {
        app.effects.init();
        setTimeout(() => app.effects.runNumberAnimations(), 100);
    }

    // --- [FIX] KHỞI ĐỘNG ĐỒNG HỒ (CẬP NHẬT LOGIC TÌM KIẾM THÔNG MINH) ---
    // --- [FIX] KHỞI ĐỘNG ĐỒNG HỒ AN TOÀN ---
    const updateClock = () => {
        try {
            const now = new Date();
            // Định dạng giờ:phút:giây
            const timeString = now.toLocaleTimeString('vi-VN', { hour12: false });

            // Tìm phần tử đồng hồ (ưu tiên ID 'clock')
            let el = document.getElementById('clock');

            // Nếu không thấy ID, tìm trong sidebar (thẻ span cạnh icon đồng hồ)
            if (!el) {
                const sidebar = document.getElementById('sidebar');
                if (sidebar) {
                    const icon = sidebar.querySelector('.fa-clock');
                    if (icon && icon.nextElementSibling) {
                        el = icon.nextElementSibling;
                    }
                }
            }

            // Chỉ cập nhật nếu tìm thấy phần tử
            if (el) {
                el.textContent = timeString;
                // Nếu muốn hiện ngày bên dưới (tuỳ chọn)
                // el.setAttribute('title', now.toLocaleDateString('vi-VN')); 
            }
        } catch (e) {
            console.warn("Lỗi đồng hồ (không ảnh hưởng app):", e);
        }
    };

    // Chạy đồng hồ mỗi giây
    setInterval(updateClock, 1000);
    updateClock(); // Chạy ngay lập tức
    // -------------------------------------------------
};
app.init = async function () {  // <-- Thêm async
    // Load config trước để biết trạng thái sidebar, v.v. (Từ IndexedDB)
    try {
        const savedConfig = await app.storage.idbGet('fm_configs');
        if (savedConfig) {
            this.data.configs = {
                ...this.data.configs,
                ...savedConfig
            };
        }

        if (this.data.configs.sidebarCollapsed) {
            document.getElementById('sidebar')?.classList.add('collapsed');
        }

        /* Khôi phục trạng thái thu gọn của bảng Cấu hình */
        const configPanel = document.getElementById('config-panel');

        if (configPanel) {
            configPanel.classList.toggle(
                'is-collapsed',
                this.data.configs.configPanelCollapsed !== false
            );
        }
    } catch (e) { }

    // Setup sự kiện
    this.events.setup();

    // Khởi động màn hình khóa (Nó sẽ tự gọi startSession nếu không khóa)
    this.security.init();

    // Setup giao diện cơ bản (lịch, v.v.)
    this.ui.init();
    const originalTxOpen = app.ui.modals.transaction.open;
    app.ui.modals.transaction.open = function (id) {
        originalTxOpen.call(this, id);

        if (id) {
            const tx = app.data.transactions.find(t => t.id === id);
            if (tx) {
                // 1. Phục hồi đúng giờ địa phương
                if (tx.date) {
                    const d = new Date(tx.date);
                    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
                    document.getElementById('tx-date').value = d.toISOString().slice(0, 16);
                }

                // 2. Phục hồi Giá gốc và trạng thái Hoàn tiền
                const discountAmt = tx.discountAmount || 0;

                // Phục hồi trạng thái tick của ô Hoàn tiền trước khi tính toán
                const txCashbackCheck = document.getElementById('tx-is-cashback');
                if (txCashbackCheck) {
                    txCashbackCheck.checked = tx.isCashback || false;
                    if (app.ui && app.ui.toggleCashbackMode) app.ui.toggleCashbackMode();
                }

                if (discountAmt > 0) {
                    // FIX: Nếu là hoàn tiền, giá gốc không đổi. Nếu là giảm giá, giá gốc = tiền thực trả + tiền giảm
                    const originalPrice = tx.isCashback ? tx.amount : (tx.amount + discountAmt);

                    // Điền lại giá gốc vào ô số tiền (có format dấu phẩy cho đẹp)
                    document.getElementById('tx-amount').value = new Intl.NumberFormat('vi-VN').format(originalPrice);

                    // Điền lại mức giảm giá vào ô Giảm giá
                    document.getElementById('tx-discount').value = tx.discountValue || discountAmt;

                    // Gọi hàm tính toán để hiển thị lại dòng gợi ý "Gốc - Giảm = Còn lại"
                    if (app.ui.calcDiscount) app.ui.calcDiscount();
                } else {
                    // Nếu không có giảm giá thì xóa trắng ô giảm giá đi cho sạch
                    document.getElementById('tx-discount').value = '';
                    if (document.getElementById('discount-hint')) document.getElementById('discount-hint').innerHTML = '';
                }
            }
        }

        // MỞ KHÓA RESET TOÀN BỘ Ô NHẬP LIỆU MỖI KHI MỞ FORM
        document.querySelectorAll('#form-tx input, #form-tx select, #form-tx textarea').forEach(el => {
            el.disabled = false; el.style.opacity = '1';
        });

        // FIX: Chỉ ép reset ô Hoàn tiền nếu là tạo Giao dịch MỚI
        if (!id) {
            const txCashbackCheck = document.getElementById('tx-is-cashback');
            if (txCashbackCheck) {
                txCashbackCheck.checked = false;
                if (app.ui && app.ui.toggleCashbackMode) app.ui.toggleCashbackMode();
            }
        }

        const txSource = document.getElementById('tx-source');
        const txDest = document.getElementById('tx-destination');
        const txBrand = document.getElementById('tx-brand');

        const txRef = document.getElementById('tx-ref');
        const txOrderCode = document.getElementById('tx-order-code');
        const lockFlagRef = document.getElementById('tx-fully-locked-flag');
        const lockFlagOrder = document.getElementById('tx-order-fully-locked-flag');
        const txSubmitBtn = document.querySelector('#form-tx button[type="submit"]');

        const bankWalletKeywords = ['shopeepay', 'bank', 'vcb', 'vietcombank', 'mb', 'mbbank', 'tpbank', 'tpb', 'bidv', 'agribank', 'vietinbank', 'ctg', 'acb', 'vpbank', 'techcombank', 'tcb', 'vib', 'sacombank', 'stb', 'shb', 'hdbank', 'scb', 'ocb', 'msb', 'nam a', 'seabank', 'abbank', 'oceanbank', 'momo', 'zalo', 'zalopay', 'viettel', 'vnpay', 'ví', 'tín dụng', 'credit'];
        const ecomKeywords = ['Go', 'sen do', 'sen đỏ', 'sendo', 'shopee', 'lazada', 'tiki', 'tiktok', 'shein', 'taobao', 'amazon', 'aliexpress', 'sendo', 'sen đỏ', 'foody', 'grab', 'Grabfood', 'Befood', 'Be', 'Be food', 'shopeefood'];
        const hybridKeywords = ['bhx', 'BHX', 'bách hóa xanh', 'bach hoa xanh', 'coop', 'co-op', 'winmart', 'vinmart', 'go', 'Go', 'cellphone', 'tgdd', 'thế giới di động', 'fpt', 'điện máy xanh', 'dmx', 'hasaki', 'guardian', 'pharmacity', 'long châu', 'phúc long', 'highland'];

        const currentSourceVal = txSource ? txSource.value.toLowerCase() : '';
        const currentDestBrandVal = ((txDest ? txDest.value : '') + ' ' + (txBrand ? txBrand.value : '')).toLowerCase();

        const isRefDetectedInit = bankWalletKeywords.some(k => currentSourceVal.includes(k));
        const isOrderDetectedInit = ecomKeywords.some(k => currentDestBrandVal.includes(k));

        let is3DaysOld = false;
        let txData = null;
        if (id) {
            txData = app.data.transactions.find(t => t.id === id);
            if (txData && txData.id) {
                // Xác định số ngày khóa: Hoàn tiền là 1 ngày, bình thường là 3 ngày
                const isCashback = txData.tags && txData.tags.includes('#hoan_tien');
                const lockDays = isCashback ? 1 : 3;

                if ((Date.now() - txData.id) / (1000 * 3600 * 24) > lockDays) is3DaysOld = true;
            }
        }

        if (id && txData && txData.type === 'Chuyển tiền') {
            const txTypeEl = document.getElementById('tx-type');
            if (txTypeEl) {
                txTypeEl.disabled = true;
                txTypeEl.style.opacity = '0.6';
                txTypeEl.setAttribute('title', 'Giao dịch chuyển tiền không thể đổi sang loại khác.');
            }
        }

        // --- [THÊM MỚI] LOGIC HIỂN THỊ DÒNG CHỮ ĐỎ (STATUS) ---
        const unknownStatus = document.getElementById('tx-unknown-status');
        if (unknownStatus) {
            // Hiện chữ đỏ nếu giao dịch cũ đã lưu là "Không rõ giờ"
            unknownStatus.style.display = (txData && txData.isUnknownTime) ? 'inline' : 'none';
        }

        const unknownCheckbox = document.getElementById('tx-is-unknown-time');
        if (unknownCheckbox) {
            // Khi người dùng tích/bỏ tích, chữ đỏ sẽ hiện/ẩn theo ngay lập tức
            unknownCheckbox.onchange = (e) => {
                if (unknownStatus) unknownStatus.style.display = e.target.checked ? 'inline' : 'none';
            };
        }
        // ------------------------------------------------------

        // ==========================================
        // ĐẾM NGƯỢC 2 NGÀY ĐỂ ẨN CHECKBOX "KHÔNG RÕ GIỜ"
        // ==========================================
        if (app.ui.unknownTimeInterval) clearInterval(app.ui.unknownTimeInterval);
        const unknownWrapper = document.getElementById('tx-unknown-time-wrapper');
        const countdownEl = document.getElementById('tx-unknown-time-countdown');

        if (unknownWrapper) {
            unknownWrapper.style.display = 'flex'; // Mặc định hiển thị khi mở form
            if (countdownEl) countdownEl.innerText = '';

            if (id && txData && txData.id) {
                const isCashback = txData.tags && txData.tags.includes('#hoan_tien');
                const lockDays = isCashback ? 1 : 3;

                const timeSinceCreation = Date.now() - txData.id;
                const lockDurationMs = lockDays * 24 * 60 * 60 * 1000;
                const hideDurationMs = (lockDays + 2) * 24 * 60 * 60 * 1000;

                if (timeSinceCreation >= hideDurationMs) {
                    // Đã quá hạn -> Ẩn hoàn toàn đi
                    unknownWrapper.style.display = 'none';
                } else if (timeSinceCreation >= lockDurationMs) {
                    // Đã bị khóa -> Bắt đầu đếm ngược 48 tiếng để ẩn
                    const updateCountdown = () => {
                        const modal = document.getElementById('modal-tx');
                        if (!modal || !modal.classList.contains('active')) {
                            clearInterval(app.ui.unknownTimeInterval);
                            return;
                        }

                        const timeLeft = hideDurationMs - (Date.now() - txData.id);
                        if (timeLeft <= 0) {
                            unknownWrapper.style.display = 'none';
                            clearInterval(app.ui.unknownTimeInterval);
                            return;
                        }

                        const h = Math.floor(timeLeft / (1000 * 60 * 60));
                        const m = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
                        const s = Math.floor((timeLeft % (1000 * 60)) / 1000);

                        if (countdownEl) countdownEl.innerText = `(Ẩn sau: ${h}h ${m}p ${s}s)`;
                    };

                    updateCountdown();
                    app.ui.unknownTimeInterval = setInterval(updateCountdown, 1000);
                }
            }
        }
        // ==========================================

        const setupField = (dataVal, elInput, elOriginal, elContainer, elBadge, isDetected) => {
            elInput.value = dataVal || '';
            document.getElementById(elOriginal).value = dataVal || '';
            document.getElementById(elContainer).style.display = dataVal ? 'block' : (isDetected ? 'block' : 'none');
            document.getElementById(elBadge).style.display = dataVal ? 'none' : (isDetected ? 'inline-block' : 'none');
        };

        setupField(txData?.refId, txRef, 'tx-original-ref', 'tx-ref-container', 'tx-ref-badge', isRefDetectedInit);
        setupField(txData?.orderCode, txOrderCode, 'tx-original-order-code', 'tx-order-code-container', 'tx-order-badge', isOrderDetectedInit);
        if (lockFlagRef) lockFlagRef.value = txData?.isRefFullyLocked ? 'true' : 'false';
        if (lockFlagOrder) lockFlagOrder.value = txData?.isOrderCodeFullyLocked ? 'true' : 'false';

        // ==========================================
        // QUẢN LÝ QUYỀN TRUY CẬP QUÁ 3 NGÀY
        // ==========================================
        if (document.getElementById('tx-ref-error')) document.getElementById('tx-ref-error').style.display = 'none';
        if (document.getElementById('tx-order-error')) document.getElementById('tx-order-error').style.display = 'none';

        const isNotLockedStatus = (txData?.status === 'planned') || (txData?.type === 'Thu nhập' && txData?.status === 'pending');

        if (is3DaysOld && !isNotLockedStatus) {
            let isRefLocked = (txData && txData.isRefFullyLocked);
            let isOrderLocked = (txData && txData.isOrderCodeFullyLocked); // Kiểm tra cờ khóa mã đơn hàng

            // Xử lý khóa Mã Giao Dịch
            if (isRefLocked && txRef) {
                txRef.disabled = true; txRef.style.opacity = '0.6';
                document.getElementById('tx-ref-error').style.display = 'block';
                document.getElementById('tx-ref-error').innerHTML = '<i class="fa-solid fa-lock"></i> Mã GD khóa vĩnh viễn.';
            }

            // Xử lý khóa Mã Đơn Hàng
            if (isOrderLocked && txOrderCode) {
                txOrderCode.disabled = true; txOrderCode.style.opacity = '0.6';
                document.getElementById('tx-order-error').style.display = 'block';
                document.getElementById('tx-order-error').innerHTML = '<i class="fa-solid fa-lock"></i> Mã Đơn khóa vĩnh viễn.';
            }

            // Quản lý hiển thị nút Lưu
            if (txSubmitBtn) {
                if (isRefLocked && isOrderLocked) {
                    txSubmitBtn.style.display = 'none'; // Khóa cả 2 thì ẩn nút
                } else {
                    txSubmitBtn.style.display = 'block';
                    txSubmitBtn.disabled = false;
                    txSubmitBtn.style.opacity = '1';
                    txSubmitBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Cập nhật Mã Bổ Sung';
                }
            }

            // Khóa các trường thông tin khác (Tự động khóa Nguồn tiền/Chuyển tới sau 1 ngày nếu là hoàn tiền)
            const isCashbackTx = txData && txData.tags && txData.tags.includes('#hoan_tien');
            const excludedFields = isCashbackTx
                ? ['tx-ref', 'tx-order-code', 'tx-brand']
                : ['tx-ref', 'tx-order-code', 'tx-source', 'tx-destination', 'tx-brand'];

            document.querySelectorAll('#form-tx input, #form-tx select, #form-tx textarea').forEach(el => {
                if (!excludedFields.includes(el.id) && el.type !== 'hidden') {
                    el.disabled = true; el.style.opacity = '0.6';
                }
            });
        }

        // ==========================================
        // [MỚI CẬP NHẬT] KHÓA GIAO DỊCH HOÀN TIỀN TỰ ĐỘNG
        // ==========================================
        const lockedMsg = document.getElementById('tx-locked-msg');
        if (lockedMsg) {
            lockedMsg.style.display = 'none';
        }

        if (id && txData && txData.tags && txData.tags.includes('#hoan_tien')) {
            // Đã loại bỏ 'tx-source' và 'tx-destination' để mở khóa cho điền dữ liệu
            const lockedFields = [
                'tx-discount',
                'tx-is-cashback',
                'tx-type',
                'tx-status',
                'tx-date',
                'tx-is-unknown-time'
            ];

            // Chỉ vô hiệu hóa các ô còn lại trong danh sách
            lockedFields.forEach(fieldId => {
                const el = document.getElementById(fieldId);
                if (el) {
                    el.disabled = true;
                    el.style.opacity = '0.6';
                }
            });

            // Hiển thị thông báo trạng thái giao dịch tự động
            if (lockedMsg) {
                lockedMsg.style.display = 'flex';
                lockedMsg.innerHTML = '<i class="fa-solid fa-link"></i> Giao dịch Hoàn tiền (Hạn chế sửa)';
                lockedMsg.style.background = '#e0f2fe';
                lockedMsg.style.color = '#0284c7';
                lockedMsg.style.border = '1px solid #bae6fd';
            }
        }
        // ==========================================
        // ==========================================
        // SỰ KIỆN QUÉT CHỮ TRỰC TIẾP
        // ==========================================
        // Tìm đến đoạn checkEcomLogic trong 6-main.js
        const checkEcomLogic = () => {
            // Lấy giá trị của cả 2 ô, đề phòng người dùng nhập vào ô nào cũng nhận
            const placeEl = document.getElementById('tx-place');
            const brandEl = document.getElementById('tx-brand');

            const placeText = placeEl ? placeEl.value.trim().toLowerCase() : '';
            const brandText = brandEl ? brandEl.value.trim().toLowerCase() : '';

            // Gộp text của cả 2 ô lại thành 1 chuỗi dài để quét từ khóa cho tiện
            const combinedText = `${placeText} ${brandText}`;

            const ecomKeywords = ['shopee', 'lazada', 'tiki', 'tiktok', 'shein', 'taobao', 'amazon', 'aliexpress', 'sendo', 'foody', 'grabfood', 'be food', 'befood', 'shopeefood'];

            // Quét trên chuỗi đã gộp
            const isEcom = ecomKeywords.some(keyword => combinedText.includes(keyword));

            if (isEcom) {
                // Hiện ô tx-order-code
                document.getElementById('tx-order-code-container').style.display = 'block';
            } else {
                // Ẩn ô tx-order-code
                document.getElementById('tx-order-code-container').style.display = 'none';
            }
        };

        if (txDest) { const c = txDest.cloneNode(true); txDest.parentNode.replaceChild(c, txDest); c.addEventListener('input', checkEcomLogic); }
        if (txBrand) { const c = txBrand.cloneNode(true); txBrand.parentNode.replaceChild(c, txBrand); c.addEventListener('input', checkEcomLogic); }
        if (txSource) {
            const c = txSource.cloneNode(true); txSource.parentNode.replaceChild(c, txSource);
            c.addEventListener('input', (e) => {
                if (bankWalletKeywords.some(k => e.target.value.toLowerCase().includes(k))) {
                    document.getElementById('tx-ref-container').style.display = 'block';
                    document.getElementById('tx-ref-badge').style.display = 'inline-block';
                } else if (!txRef.value.trim() && !document.getElementById('tx-original-ref').value.trim()) {
                    document.getElementById('tx-ref-container').style.display = 'none';
                }
            });
        }

        // Giao dịch hạn mức: số tiền luôn lấy từ cấu hình tháng, không sửa trực tiếp.
        if (id && txData && app.logic.isMonthlyLimitCreditTransaction(txData)) {
            const assignedMonth = app.logic.getMonthlyLimitCreditMonth(txData);
            const configuredAmount = app.logic.getMonthlyLimitCreditAmount(assignedMonth);
            const amountInput = document.getElementById('tx-amount');
            const typeInput = document.getElementById('tx-type');
            const discountInput = document.getElementById('tx-discount');
            const cashbackInput = document.getElementById('tx-is-cashback');
            const deleteButton = document.getElementById('btn-delete-tx');
            const systemMsg = document.getElementById('tx-locked-msg');

            // --- [FIX LỖI] Khai báo lại biến ở file này ---
            const statusInput = document.getElementById('tx-status');
            const matchContainer = document.getElementById('limit-income-selection-container');
            // ----------------------------------------------

            // Các trường mô tả và trạng thái vẫn được phép chỉnh sửa.
            [
                'tx-status', 'tx-place', 'tx-brand', 'tx-source',
                'tx-destination', 'tx-date', 'tx-is-unknown-time',
                'tx-tags', 'tx-ref', 'tx-order-code'
            ].forEach(fieldId => {
                const el = document.getElementById(fieldId);
                if (el) {
                    el.disabled = false;
                    el.style.opacity = '1';
                }
            });

            if (amountInput) {
                amountInput.value = new Intl.NumberFormat('vi-VN').format(configuredAmount);
                amountInput.disabled = true;
                amountInput.style.opacity = '0.6';
                amountInput.title = 'Muốn đổi số tiền, hãy sửa tại Giới hạn chi tiêu (Tháng).';
            }
            [typeInput, discountInput, cashbackInput].forEach(el => {
                if (el) {
                    el.disabled = true;
                    el.style.opacity = '0.6';
                }
            });
            if (deleteButton) deleteButton.classList.add('hidden');
            if (txSubmitBtn) {
                txSubmitBtn.style.display = 'block';
                txSubmitBtn.disabled = false;
                txSubmitBtn.style.opacity = '1';
                txSubmitBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Lưu thay đổi';
            }
            if (systemMsg) {
                const statusText = txData.status === 'paid'
                    ? 'Đã xong: đã tính là Thu nhập, không cộng lại vào Khả dụng.'
                    : 'Chưa hoàn thành: đã cộng vào Khả dụng, chưa tính là Thu nhập thực tế.';
                systemMsg.style.display = 'flex';
                systemMsg.style.background = '#eef2ff';
                systemMsg.style.color = '#4338ca';
                systemMsg.style.border = '1px solid #c7d2fe';
                systemMsg.innerHTML = `<i class="fa-solid fa-wallet"></i> ${statusText}<br><small>Số tiền đồng bộ từ Giới hạn chi tiêu (Tháng).</small>`;
            }

            // --- KIỂM TRA & HIỂN THỊ LẠI BẢNG SO KHỚP ---
            // 1. Kiểm tra xem giao dịch này ĐÃ TỪNG SO KHỚP ĐỦ TIỀN CHƯA
            // Tính tổng những giao dịch đã được gán vào hạn mức này
            const matchedIncomeTotal = app.data.transactions
                .filter(t =>
                    String(t.assignedToMonthlyLimit ?? '') === String(txData.id)
                )
                .reduce(
                    (sum, t) => sum + (Number(t.amount) || 0),
                    0
                );

            // Chỉ coi là đã so khớp khi tổng tiền đủ hạn mức
            const isAlreadyMatched =
                matchedIncomeTotal >= configuredAmount;

            // 2. Nếu trạng thái đang là 'paid' NHƯNG chưa so khớp đủ -> Bắt buộc gọi lại bảng để so khớp tiếp
            if (txData.status === 'paid' && !isAlreadyMatched) {
                app.ui.renderIncomeSelection(
                    assignedMonth,
                    configuredAmount,
                    txData.id
                );
            } else {
                if (matchContainer) matchContainer.style.display = 'none';
            }

            // 3. Bắt sự kiện khi người dùng đổi qua lại giữa 'pending' và 'paid'
            if (statusInput) {
                statusInput.onchange = function (e) {
                    if (e.target.value === 'paid' && !isAlreadyMatched) {
                        app.ui.renderIncomeSelection(assignedMonth, configuredAmount);
                    } else {
                        if (matchContainer) matchContainer.style.display = 'none';
                    }
                };
            }
        }
    };
};

app.events = {
    setup() {
        // 1. Logic cũ: Đóng menu khi bấm vào một mục bên trong sidebar
        document.querySelectorAll('#sidebar .menu-item, #btn-reset-data').forEach(el => {
            el.addEventListener('click', () => {
                const sidebar = document.getElementById('sidebar');
                // Kiểm tra: Nếu là màn hình nhỏ VÀ Sidebar đang mở (active) -> Thì đóng lại
                if (window.innerWidth <= 768 && sidebar && sidebar.classList.contains('active')) {
                    app.ui.toggleMobileMenu();
                }
            });
        });

        // Nút thu gọn toàn bộ sidebar
        document.getElementById('btn-toggle-sidebar').addEventListener('click', () => {
            const sidebar = document.getElementById('sidebar');

            sidebar.classList.toggle('collapsed');

            app.data.configs.sidebarCollapsed =
                sidebar.classList.contains('collapsed');

            app.storage.save();
        });

        // Thu gọn hoặc mở riêng bảng Cấu hình
        const configPanel = document.getElementById('config-panel');
        const configPanelHeader = document.getElementById('config-panel-header');

        if (configPanel && configPanelHeader) {
            configPanelHeader.addEventListener('click', event => {
                if (event.target.closest('button')) return;

                configPanel.classList.toggle('is-collapsed');

                app.data.configs.configPanelCollapsed =
                    configPanel.classList.contains('is-collapsed');

                app.storage.save();
            });
        }

        // 3. [THÊM MỚI] Logic đóng menu khi chạm ra ngoài vùng menu (Mobile)
        document.addEventListener('click', (event) => {
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.querySelector('.mobile-menu-toggle');

            // Chỉ chạy khi ở giao diện Mobile và menu đang mở
            if (window.innerWidth <= 768 && sidebar && sidebar.classList.contains('active')) {
                // Nếu điểm chạm KHÔNG nằm trong sidebar VÀ KHÔNG nằm trong nút mở menu
                if (!sidebar.contains(event.target) && menuToggle && !menuToggle.contains(event.target)) {
                    app.ui.toggleMobileMenu(); // Gọi lại hàm toggle của bạn để đóng
                }
            }
        });

        // 4. Logic cũ: Đóng Modal
        document.querySelectorAll('.close-modal').forEach(b => {
            b.onclick = function () {
                this.closest('.modal-overlay').classList.remove('active');
                if (this.closest('#modal-tx') && app.ui.transactionModalInterval) {
                    clearInterval(app.ui.transactionModalInterval);
                    app.ui.transactionModalInterval = null;
                }
            };
        });

        // Mobile: chạm đúng vùng nền tối bên ngoài form giao dịch để đóng.
        // Không chạy khi chạm bên trong modal và không thay đổi dữ liệu đã lưu.
        const transactionOverlay = document.getElementById('modal-tx');
        if (transactionOverlay && !transactionOverlay.dataset.mobileBackdropCloseBound) {
            transactionOverlay.dataset.mobileBackdropCloseBound = 'true';

            transactionOverlay.addEventListener('click', (event) => {
                if (window.innerWidth > 768) return;
                if (event.target !== transactionOverlay) return;

                transactionOverlay.classList.remove('active');

                if (app.ui.transactionModalInterval) {
                    clearInterval(app.ui.transactionModalInterval);
                    app.ui.transactionModalInterval = null;
                }
            });
        }

        const removeAccents = (str) => {
            return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "")
                .replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase();
        };

        document.getElementById('search-input').addEventListener('input', (e) => {
            const keyword = e.target.value.trim();
            if (!keyword) {
                app.ui.renderAll();
                return;
            }
            const normalizeKey = removeAccents(keyword);
            const results = app.data.transactions.filter(t => {
                // Bổ sung refId và orderCode vào chuỗi nội dung để tìm kiếm
                const content = `${t.place} ${t.source} ${t.amount} ${t.tags || ''} ${t.note || ''} ${t.refId || ''} ${t.orderCode || ''}`;
                return removeAccents(content).includes(normalizeKey);
            });

            document.getElementById('periodDisplay').innerHTML = `<span style="color:var(--primary)">Tìm thấy: ${results.length} giao dịch</span>`;
            document.querySelector('.page-subtitle').textContent = `Kết quả tìm kiếm cho: "${keyword}"`;

            const tbody = document.getElementById('tx-table-body');
            if (results.length === 0) {
                tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:2rem; color:var(--text-muted)">Không tìm thấy giao dịch nào khớp lệnh!</td></tr>`;
            } else {
                tbody.innerHTML = results
                    .sort((a, b) => app.logic.compareTransactions(a, b))
                    .map(t => {
                        const isInc = t.type === 'Thu nhập';
                        const isCancelled = t.status === 'cancelled';
                        let statusText = isCancelled ? 'Đã hủy' : (t.status === 'paid' ? 'Thành công' : (t.status === 'planned' ? 'Dự kiến' : 'Chưa trả'));
                        let badgeClass = isCancelled ? 'badge-secondary' : (t.status === 'paid' ? 'badge-success' : 'badge-warning');
                        const statusTags = String(t.tags || '').toLowerCase();
                        if (!isCancelled && statusTags.includes('#da_chuyen_tra_gop')) {
                            statusText = 'Đã chuyển trả góp';
                            badgeClass = 'badge-warning';
                        } else if (!isCancelled && t.paidByGroup) {
                            statusText = 'Đã tất toán';
                        }
                        const amountClass = isInc ? 'var(--success)' : (isCancelled ? 'var(--text-muted)' : 'inherit');
                        const rowClass = isCancelled ? 'tx-cancelled' : '';
                        const amountPrefix = isInc ? '+' : '-';

                        return `<tr class="${rowClass}" onclick="if(!event.target.closest('button')) app.ui.modals.transaction.open(${t.id})" style="cursor:pointer">
                <td style="color:var(--text-muted)">${new Date(t.date).toLocaleDateString('vi-VN')}</td>
                <td>
                    <div style="font-weight:600">${t.place}</div>
                    <div style="font-size:0.75rem; color:var(--text-muted)">${t.tags || ''}</div>
                </td>
                <td>${t.source}</td>
                <td style="font-family:var(--font-mono); font-weight:700; color: ${amountClass}">
                    ${amountPrefix}${app.logic.formatCurrency(t.amount)}
                </td>
                <td><span class="badge ${badgeClass}">${statusText}</span></td>
                <td style="text-align:right">
                    <button class="btn-ghost btn-sm" onclick="app.ui.modals.transaction.open(${t.id})"><i class="fa-solid fa-pen"></i></button>
                </td>
            </tr>`;
                    }).join('');
            }
        });

        document.getElementById('btn-save-manual-zalo').onclick = () => {
            const count = app.data.configs.zaloManualCount || 0;

            // 1. Kiểm tra giới hạn (Thay alert bằng popup warning)
            if (count >= 100) {
                return app.ui.popup.show("Bạn đã hết lượt chỉnh sửa thủ công!", "warning");
            }

            const rank = document.getElementById('manual-rank-select').value;
            const amountStr = document.getElementById('manual-amount-input').value;

            // Logic tính toán Offset (Giữ nguyên)
            if (!amountStr) {
                // Nếu xóa trắng ô nhập -> Reset về tính tự động
                app.data.configs.manualZaloOffset = 0;
                app.data.configs.manualZaloAmount = null;
            } else {
                const targetAmount = Number(amountStr.replace(/[^0-9]/g, '')); // Lọc lấy số

                // TÍNH LẠI TỔNG THỰC TẾ HIỆN TẠI (để tìm chênh lệch)
                const currentReal = app.logic.getZaloAccumulation(true);

                // Tính độ lệch: Offset = Số mong muốn - Số thực tế
                const offset = targetAmount - currentReal;

                // Lưu độ lệch này lại
                app.data.configs.manualZaloOffset = offset;
                app.data.configs.manualZaloAmount = targetAmount;
            }

            if (rank) {
                app.data.configs
                    .zaloCurrentRank =
                    rank;

                app.data.configs
                    .manualZaloRank =
                    rank;
            } else {
                app.data.configs
                    .manualZaloRank =
                    null;
            }

            app.data.configs
                .zaloManualCount =
                count + 1;

            // Lưu và Render lại
            app.storage.save();
            app.logic.updateFees();
            app.ui.renderAll();
            app.ui.renderZaloWidget();

            // Mở lại modal để thấy thay đổi (nếu cần)
            // app.ui.modals.zalo.open(); 

            // 2. Thông báo thành công (Thay alert bằng popup success)
            app.ui.popup.show("✨ Đã áp dụng phép màu!<br>Hạng và Số tiền tích lũy đã được cập nhật.", "success");
        };

        document.getElementById('form-tx').addEventListener('submit', async (e) => {
            e.preventDefault();
            const id = document.getElementById('tx-id').value;
            const originalTxForSubmit = id
                ? app.data.transactions.find(t => t.id == id)
                : null;
            const isMonthlyLimitCreditTx =
                app.logic.isMonthlyLimitCreditTransaction(originalTxForSubmit || {});

            // --- 👇 BỔ SUNG DÒNG NÀY VÀO ĐÂY 👇 ---
            const destinationVal = document.getElementById('tx-destination') ? document.getElementById('tx-destination').value : '';
            // ----------------------------------------

            const sourceVal = document.getElementById('tx-source').value;

            // --- [MỚI] KIỂM TRA NGÂN HÀNG BỊ KHÓA ---
            let isBlocked = false;
            let blockedBankName = "";

            if (app.data.accounts) {
                const lowerSource = sourceVal.toLowerCase().trim();
                const lowerDest = destinationVal.toLowerCase().trim();

                for (const account of app.data.accounts) {
                    if (account.isLocked) {
                        const lowerBank = account.bankName.toLowerCase().trim();
                        if (lowerSource === lowerBank || lowerDest === lowerBank) {
                            isBlocked = true;
                            blockedBankName = account.bankName;
                            break;
                        }
                    }
                }
            }

            if (isBlocked) {
                return app.ui.popup.show(`⛔ LỖI: Không thể thao tác với ngân hàng <b>${blockedBankName}</b> vì thẻ này đã bị khóa. Vui lòng mở khóa thẻ trước!`, "error");
            }

            const originalAmount = Number(document.getElementById('tx-amount').value.replace(/[^0-9]/g, ''));
            const discountText =
                document.getElementById('tx-discount')
                    .value
                    .trim()
                    .toLowerCase();

            const discountRaw =
                discountText.replace(/[^0-9]/g, '');

            const discountInput =
                Number(discountRaw) || 0;

            const hasPercent =
                discountText.includes('%');

            const hasCurrency =
                discountText.includes('đ') ||
                discountText.includes('vnd');

            const isPercentDiscount =
                hasPercent ||
                (!hasCurrency && discountInput <= 100);

            let finalAmount = originalAmount;
            let discountMoney = 0;
            let actualDiscountToSave = 0;

            // KIỂM TRA XEM CÓ ĐANG TICK "HOÀN TIỀN" KHÔNG
            const isCashback = document.getElementById('tx-is-cashback') ? document.getElementById('tx-is-cashback').checked : false;

            if (discountInput > 0) {
                if (isPercentDiscount) {
                    discountMoney = Math.round(originalAmount * (discountInput / 100));
                } else {
                    discountMoney = discountInput;
                }

                // Nếu KHÔNG PHẢI hoàn tiền thì mới trừ vào giá trị thực tế của Giao dịch chính
                if (!isCashback) {
                    finalAmount = originalAmount - discountMoney;
                    actualDiscountToSave = discountMoney;
                }
            }

            const isUnknownTime = document.getElementById('tx-is-unknown-time') ? document.getElementById('tx-is-unknown-time').checked : false;
            let finalDateStr = document.getElementById('tx-date').value;

            if (isUnknownTime) {
                const datePart = finalDateStr.split('T')[0];
                finalDateStr = `${datePart}T12:00:00`; // Đổi thành 12h trưa để fix lỗi lùi ngày (Timezone UTC)
            }

            let finalDateISO = finalDateStr;

            try {
                // Đóng gói lại thành chuẩn quốc tế (UTC) để lưu
                finalDateISO = new Date(finalDateStr).toISOString();
            } catch (e) { }

            // Nếu đang sửa và người dùng không đổi giờ phút, thì GIỮ NGUYÊN chuỗi gốc để không mất số giây
            if (id) {
                const originalTx = app.data.transactions.find(t => t.id == id);
                if (originalTx && originalTx.date) {
                    const origDateObj = new Date(originalTx.date);
                    origDateObj.setMinutes(origDateObj.getMinutes() - origDateObj.getTimezoneOffset());
                    const origLocalStr = origDateObj.toISOString().slice(0, 16);

                    if (finalDateStr === origLocalStr) {
                        finalDateISO = originalTx.date;
                    }
                }
            } else if (!finalDateStr.includes('Z')) {
                // Thêm mới hoàn toàn
                finalDateISO = new Date(finalDateStr).toISOString();
            }

            const data = {
                id: id ? Number(id) : Date.now(),
                type: document.getElementById('tx-type').value,
                status: document.getElementById('tx-status').value,

                amount: finalAmount,
                discountAmount: discountMoney,
                discountValue: discountInput > 0 ? discountInput : null,

                place: document.getElementById('tx-place').value,
                brand: document.getElementById('tx-brand').value,
                source: document.getElementById('tx-source').value,
                destination: document.getElementById('tx-destination') ? document.getElementById('tx-destination').value : '',
                refId: document.getElementById('tx-ref') ? document.getElementById('tx-ref').value.trim() : '',
                isRefFullyLocked: document.getElementById('tx-fully-locked-flag') ? (document.getElementById('tx-fully-locked-flag').value === 'true') : false,
                orderCode: document.getElementById('tx-order-code') ? document.getElementById('tx-order-code').value.trim() : '',
                isOrderCodeFullyLocked: document.getElementById('tx-order-fully-locked-flag') ? (document.getElementById('tx-order-fully-locked-flag').value === 'true') : false,

                // [ĐÃ SỬA] Gán biến ngày giờ an toàn vừa tính toán vào đây
                date: finalDateISO,
                isUnknownTime: isUnknownTime,

                tags: document.getElementById('tx-tags').value,
                isTet: document.getElementById('tx-is-tet').checked,
                is83: document.getElementById('tx-is-83') ? document.getElementById('tx-is-83').checked : false,
                is304: document.getElementById('tx-is-304') ? document.getElementById('tx-is-304').checked : false,

                // 👇 THÊM DÒNG NÀY ĐỂ DATABASE NHỚ ĐÂY LÀ HOÀN TIỀN
                isCashback: isCashback
            };


            // ==================================================
            // CHỌN NGUỒN NGÂN SÁCH: TIỀN THỰC / HẠN MỨC THÁNG
            // ==================================================
            if (!isMonthlyLimitCreditTx) {
                const isExpense = data.type === 'Chi tiêu';
                const isDebtPayment =
                    data.type === 'Trả nợ' ||
                    app.logic.isDebtPaymentTransaction(data);

                if (!isExpense || isDebtPayment) {
                    data.budgetFunding = 'none';
                } else {
                    const creditText = [data.source, data.destination]
                        .filter(Boolean)
                        .join(' ');

                    const fundingMonth = app.logic.getLocalMonthKey(data.date);
                    const isSep2026FutureIncomeMode =
                        app.logic.isMonthlyLimitFutureIncomeEnabled &&
                        app.logic.isMonthlyLimitFutureIncomeEnabled(fundingMonth);

                    // 09/2026: ZaloPay/Zalo Priority thường KHÔNG đồng nghĩa với Ví Trả Sau.
                    // Chỉ tự động dùng Hạn mức khi tên nguồn thể hiện rõ đây là tín dụng/trả sau.
                    // Ngoài 09/2026 giữ nguyên nhận diện cũ để không ảnh hưởng logic tháng khác.
                    const explicitCreditText = String(creditText || '').toLowerCase();
                    const isExplicitPayLater =
                        explicitCreditText.includes('trả sau') ||
                        explicitCreditText.includes('tra sau') ||
                        explicitCreditText.includes('paylater') ||
                        explicitCreditText.includes('pay later') ||
                        explicitCreditText.includes('spaylater') ||
                        explicitCreditText.includes('spay later') ||
                        explicitCreditText.includes('thẻ tín dụng') ||
                        explicitCreditText.includes('the tin dung') ||
                        explicitCreditText.includes('credit card');

                    const isCreditPurchase = isSep2026FutureIncomeMode
                        ? isExplicitPayLater
                        : app.logic.isCreditSource(creditText);

                    if (id && originalTxForSubmit) {
                        // Khi sửa giao dịch cũ, giữ nguyên lựa chọn trước đó
                        // để không hỏi lại và không tự đổi nguồn ngân sách.
                        data.budgetFunding =
                            app.logic.getTransactionBudgetFunding(
                                originalTxForSubmit
                            );
                    } else if (isSep2026FutureIncomeMode) {
                        // 09/2026 — CƠ CHẾ ĐƠN GIẢN:
                        // Chỉ hỏi Tiền thực / Hạn mức khi:
                        // 1) giao dịch đang Ghi nợ / Chưa trả (status = pending), HOẶC
                        // 2) nguồn là Trả sau / PayLater / SPayLater / thẻ tín dụng.
                        // Các giao dịch chi tiêu đã trả thông thường mặc định là Tiền thực.
                        const isUnpaidDebt = data.status === 'pending';
                        const shouldAskBudgetFunding =
                            isUnpaidDebt || isExplicitPayLater;

                        const limitStateBefore = app.logic.getMonthlyLimitState(
                            fundingMonth,
                            { excludeTransactionId: data.id }
                        );

                        if (
                            shouldAskBudgetFunding &&
                            limitStateBefore.configured > 0
                        ) {
                            const realBalanceBefore = app.logic.getRealCashBalance(
                                fundingMonth,
                                { excludeTransactionId: data.id }
                            );

                            data.budgetFunding = await app.ui.popup.selectBudgetFunding({
                                amount: data.amount,
                                source: data.source,
                                realBalance: realBalanceBefore,
                                limitRemaining: limitStateBefore.remaining,
                                recommendLimit: isUnpaidDebt || realBalanceBefore <= 0
                            });
                        } else {
                            data.budgetFunding = 'real';
                        }
                    } else if (isCreditPurchase) {
                        // Các tháng khác giữ nguyên logic cũ:
                        // nguồn tín dụng/trả sau tự động dùng hạn mức.
                        data.budgetFunding = 'limit';
                    } else {
                        const limitStateBefore = app.logic.getMonthlyLimitState(
                            fundingMonth,
                            { excludeTransactionId: data.id }
                        );

                        if (limitStateBefore.configured > 0) {
                            const realBalanceBefore = app.logic.getRealCashBalance(
                                fundingMonth,
                                { excludeTransactionId: data.id }
                            );

                            data.budgetFunding = await app.ui.popup.selectBudgetFunding({
                                amount: data.amount,
                                source: data.source,
                                realBalance: realBalanceBefore,
                                limitRemaining: limitStateBefore.remaining,
                                recommendLimit: realBalanceBefore <= 0
                            });
                        } else {
                            // Chưa cấu hình hạn mức cho tháng này => mặc định tiền thực.
                            data.budgetFunding = 'real';
                        }
                    }
                }
            }

            // Giữ liên kết cũ khi người dùng sửa giao dịch.
            if (
                originalTxForSubmit?.linkedTransferId !==
                undefined &&
                originalTxForSubmit?.linkedTransferId !==
                null &&
                originalTxForSubmit?.linkedTransferId !==
                ''
            ) {
                data.linkedTransferId =
                    originalTxForSubmit.linkedTransferId;
            }

            if (
                originalTxForSubmit?.linkedExpenseId !==
                undefined &&
                originalTxForSubmit?.linkedExpenseId !==
                null &&
                originalTxForSubmit?.linkedExpenseId !==
                ''
            ) {
                data.linkedExpenseId =
                    originalTxForSubmit.linkedExpenseId;
            }

            if (isMonthlyLimitCreditTx) {
                const assignedMonth = app.logic.getMonthlyLimitCreditMonth(originalTxForSubmit);
                const configuredAmount = app.logic.getMonthlyLimitCreditAmount(assignedMonth);
                const tags = String(data.tags || '')
                    .split(/\s+/)
                    .filter(Boolean);

                if (!tags.includes('#gioi_han_chi_tieu_tu_dong')) {
                    tags.push('#gioi_han_chi_tieu_tu_dong');
                }

                // Cập nhật trạng thái
                const userSelectedStatus = document.getElementById('tx-status').value;
                data.status = userSelectedStatus === 'paid' ? 'paid' : 'pending';

                data.type = 'Thu nhập';
                data.amount = configuredAmount;
                data.discountAmount = 0;
                data.discountValue = null;
                data.isCashback = false;
                data.isMonthlyLimitCredit = true;
                data.monthlyLimitMonth = assignedMonth;
                data.tags = tags.join(' ');

                // --- [MỚI] LOGIC XỬ LÝ KHI NGƯỜI DÙNG XÁC NHẬN GIAO DỊCH HẠN MỨC ---
                // --- XỬ LÝ SO KHỚP THU NHẬP CHO GIAO DỊCH HẠN MỨC ---
                if (data.status === 'paid') {
                    const checks =
                        document.querySelectorAll(
                            '.limit-income-chk:checked'
                        );

                    let selectedSum = 0;
                    const selectedIds = [];

                    checks.forEach(chk => {
                        selectedSum +=
                            Number(
                                chk.getAttribute('data-amount')
                            ) || 0;

                        selectedIds.push(
                            Number(chk.value)
                        );
                    });

                    // Những khoản đã khớp từ lần lưu trước
                    const alreadyMatchedTotal =
                        app.data.transactions
                            .filter(t =>
                                String(
                                    t.assignedToMonthlyLimit ?? ''
                                ) === String(data.id)
                            )
                            .reduce(
                                (sum, t) =>
                                    sum +
                                    (Number(t.amount) || 0),
                                0
                            );

                    /*
                     * QUAN TRỌNG:
                     * Không chặn lưu khi chưa đủ.
                     *
                     * Khoản Thu nhập được chọn chỉ dùng để SO KHỚP
                     * cho giao dịch Hạn mức. Từ thời điểm này:
                     * - Không tính riêng khoản Thu nhập được chọn nữa.
                     * - Giao dịch Hạn mức "Đã xong" là khoản Thu nhập đại diện.
                     *
                     * Không tự ý thay đổi các cờ loại trừ thủ công của người dùng.
                     * Logic tổng hợp sẽ nhận biết bằng assignedToMonthlyLimit.
                     */
                    app.data.transactions.forEach(t => {
                        if (
                            selectedIds.includes(
                                Number(t.id)
                            )
                        ) {
                            t.assignedToMonthlyLimit =
                                data.id;
                        }
                    });

                    const matchedTotal =
                        alreadyMatchedTotal +
                        selectedSum;

                    // Lưu để dễ nhận biết trạng thái
                    data.limitMatchedAmount =
                        matchedTotal;

                    data.limitMatchIncomplete =
                        matchedTotal < configuredAmount;

                } else {

                    /*
                     * Nếu người dùng chuyển Hạn mức
                     * trở lại trạng thái chưa xong,
                     * bỏ liên kết so khớp.
                     */
                    app.data.transactions.forEach(t => {
                        if (
                            String(
                                t.assignedToMonthlyLimit ?? ''
                            ) === String(data.id)
                        ) {
                            // Chỉ gỡ liên kết so khớp.
                            // Giữ nguyên lựa chọn loại trừ thủ công
                            // mà người dùng đã thiết lập cho giao dịch.
                            delete t.assignedToMonthlyLimit;
                        }
                    });

                    data.limitMatchedAmount = 0;
                    data.limitMatchIncomplete = false;
                }
            }

            // ==================================================
            // SO KHỚP GIAO DỊCH NẠP VỚI GIAO DỊCH CHI TIÊU
            // ==================================================
            if (!isMonthlyLimitCreditTx) {
                const isEligibleExpense =
                    data.type === 'Chi tiêu' &&
                    data.status === 'paid';

                if (isEligibleExpense) {
                    const existingLinkedTransfer =
                        originalTxForSubmit
                            ? app.logic
                                .getLinkedTransferForExpense(
                                    originalTxForSubmit
                                )
                            : null;

                    const matchingTransfers =
                        app.logic.findMatchingPaidTransfers(
                            data,
                            {
                                expenseId: data.id
                            }
                        );

                    // Khi sửa khoản chi đã liên kết,
                    // vẫn đưa giao dịch cũ vào danh sách.
                    if (
                        existingLinkedTransfer &&
                        !matchingTransfers.some(t =>
                            String(t.id) ===
                            String(
                                existingLinkedTransfer.id
                            )
                        )
                    ) {
                        matchingTransfers.unshift(
                            existingLinkedTransfer
                        );
                    }

                    // Mặc định Cancel/Bỏ qua:
                    // không liên kết và tính đủ mệnh giá.
                    delete data.linkedTransferId;

                    if (matchingTransfers.length > 0) {
                        const shouldSelectTransfer =
                            window.confirm(
                                `Phát hiện ${matchingTransfers.length} giao dịch nạp đã thanh toán phù hợp.\n\n` +
                                `Khoản chi: ${data.place || 'Không tên'}\n` +
                                `Mệnh giá: ${app.logic.formatCurrency(data.amount)}\n\n` +
                                `OK: Chọn giao dịch nạp để ngân sách tính số thực trả.\n` +
                                `Cancel: Không liên kết và tính đủ mệnh giá.`
                            );

                        if (shouldSelectTransfer) {
                            const selectedTransferId =
                                await app.ui.popup
                                    .selectTransferMatch(
                                        matchingTransfers,
                                        data
                                    );

                            if (
                                selectedTransferId !== null &&
                                selectedTransferId !== undefined &&
                                selectedTransferId !== ''
                            ) {
                                data.linkedTransferId =
                                    selectedTransferId;
                            }
                        }
                    }
                } else {
                    // Không còn là Chi tiêu đã thanh toán
                    // thì xóa đầu liên kết.
                    delete data.linkedTransferId;
                }
            }

            // Hiển thị thông báo nhỏ nếu có giảm giá hoặc hoàn tiền để người dùng biết
            if (discountMoney > 0) {
                if (isCashback) {
                    // Popup riêng biệt dành cho Hoàn tiền
                    app.ui.popup.show(`🎉 Đã lưu giao dịch!<br>💸 Hệ thống tự động ghi nhận khoản hoàn tiền: <b>+${new Intl.NumberFormat('vi-VN').format(discountMoney)} đ</b>`, "success");
                } else {
                    // Popup mặc định của Giảm giá
                    app.ui.popup.show(`Đã lưu: <b>${app.logic.formatCurrency(finalAmount)}</b><br>(Gốc: ${app.logic.formatCurrency(originalAmount)} - Giảm: ${app.logic.formatCurrency(discountMoney)})`, "success");
                }
            } else {
                // (Tùy chọn) Nếu bạn muốn có thông báo cho các giao dịch bình thường không giảm/hoàn
                // app.ui.popup.show("✅ Đã lưu giao dịch thành công!", "success");
            }
            // ==================================================
            // CẢNH BÁO THEO HẠN MỨC MỚI
            // Chỉ giao dịch budgetFunding = limit mới làm giảm hạn mức.
            // Nợ/thu nhập/chi bằng tiền thực không làm giảm hạn mức tháng.
            // ==================================================
            if (
                data.type === 'Chi tiêu' &&
                data.budgetFunding === 'limit' &&
                !['planned', 'cancelled'].includes(data.status)
            ) {
                const fundingMonth = app.logic.getLocalMonthKey(data.date);

                // 08-09/2026: giao dịch Trả sau/PayLater không đốt Hạn mức
                // ngay tại ngày mua. Nó sẽ được trừ khi đi vào Nợ dự phòng
                // của tháng chuẩn bị thanh toán. Vì vậy không cộng trực tiếp
                // amount lần nữa ở bước cảnh báo này.
                const deferredToDebtReserve =
                    app.logic.isMonthlyLimitDebtReserveMode &&
                    app.logic.isMonthlyLimitDebtReserveMode(fundingMonth) &&
                    app.logic.isDeferredCreditForMonthlyLimit &&
                    app.logic.isDeferredCreditForMonthlyLimit(data);

                const stateBefore = app.logic.getMonthlyLimitState(
                    fundingMonth,
                    { excludeTransactionId: data.id }
                );

                if (stateBefore.configured > 0 && !deferredToDebtReserve) {
                    const amountForLimit =
                        app.logic.getTransactionBudgetAmount(data);
                    const usedAfter =
                        stateBefore.used + (Number(amountForLimit) || 0);
                    const remainingAfter =
                        stateBefore.configured - usedAfter;

                    if (remainingAfter < 0) {
                        const over = Math.abs(remainingAfter);
                        const confirmOver = window.confirm(
                            `🚨 VƯỢT HẠN MỨC THÁNG!

` +
                            `Hạn mức thiết lập: ${app.logic.formatCurrency(stateBefore.configured)}
` +
                            `Đã dùng trước giao dịch này: ${app.logic.formatCurrency(stateBefore.used)}
` +
                            `Giao dịch mới: ${app.logic.formatCurrency(amountForLimit)}
` +
                            `---------------------------
` +
                            `VƯỢT HẠN MỨC: ${app.logic.formatCurrency(over)}

` +
                            `Bạn vẫn muốn lưu giao dịch này?`
                        );
                        if (!confirmOver) return;
                    } else if (remainingAfter < 100000) {
                        window.alert(
                            `⚠️ HẠN MỨC SẮP HẾT!

` +
                            `Sau giao dịch này bạn còn: ${app.logic.formatCurrency(remainingAfter)}
` +
                            `trong hạn mức tháng ${fundingMonth}.`
                        );
                    }
                }
            }

            const isZaloPriority =
                app.logic
                    .isZaloPrioritySource(
                        data.source
                    );

            if (
                !isMonthlyLimitCreditTx &&
                data.type === 'Chi tiêu' &&
                isZaloPriority
            ) {
                const isCounted =
                    confirm(
                        `Giao dịch ZaloPay: "${data.place}"\n\n` +

                        `Đây có phải khoản thanh toán hợp lệ để xét hạng Priority không?\n\n` +

                        `OK: Có tính\n` +
                        `Cancel: Không tính\n\n` +

                        `Không tính chuyển tiền, chuyển khoản ngân hàng, bán chứng khoán hoặc bán chứng chỉ quỹ.`
                    );

                data.skipZalo =
                    !isCounted;

            } else if (
                data.type !== 'Chi tiêu'
            ) {
                data.skipZalo = true;
            }

            if (id) {
                const originalTx = app.data.transactions.find(t => t.id == id);
                if (originalTx && originalTx.status === 'planned' && data.status !== 'planned') {
                    const previousIdForLimitIncome = data.id;
                    data.id = Date.now();

                    // 09/2026: nếu khoản Thu nhập Dự kiến đã được chọn làm nguồn
                    // bảo chứng Hạn mức, giữ liên kết khi hệ thống đổi ID lúc chuyển trạng thái.
                    if (data.type === 'Thu nhập' && app.logic.replaceMonthlyLimitLinkedIncomeId) {
                        app.logic.replaceMonthlyLimitLinkedIncomeId(
                            previousIdForLimitIncome,
                            data.id,
                            app.logic.getLocalMonthKey(data.date),
                            { save: false }
                        );
                    }

                    if (data.type === 'Thu nhập' && data.status === 'pending') {
                        app.ui.popup.show("Đã chuyển trạng thái: <b>Sắp nhận tiền</b><br>(Đang chờ về ví)", "success");
                    } else {
                        app.ui.popup.show("Đã chuyển sang chính thức!<br>Giao dịch sẽ bị khóa sau 3 ngày.", "info");
                    }
                    const idx = app.data.transactions.findIndex(t => t.id == id);
                    if (idx !== -1) app.data.transactions.splice(idx, 1);
                    app.data.transactions.push(data);
                } else {
                    if (originalTx) {
                        // Giữ lại các trường đặc biệt cũ
                        if (originalTx.forceStatementKey) data.forceStatementKey = originalTx.forceStatementKey;
                        if (originalTx.keepForZalo) data.keepForZalo = originalTx.keepForZalo;
                        if (originalTx.cancelledDate) data.cancelledDate = originalTx.cancelledDate;
                        if (originalTx.isCancelDateFixed) data.isCancelDateFixed = originalTx.isCancelDateFixed;

                        // --- [QUAN TRỌNG] BẢO LƯU TRẠNG THÁI ĐÃ DỜI ---
                        if (originalTx.isDeferred) {
                            data.isDeferred = true;
                        }

                        if (originalTx.isSourceFixed) {
                            data.isSourceFixed = true;
                        } else {
                            const lockDuration = (originalTx.tags && originalTx.tags.includes('#hoan_tien') ? 1 : 3) * 24 * 60 * 60 * 1000;
                            const isLockedTime = (Date.now() - originalTx.id) > lockDuration;
                            // Kiểm tra xem có phải giao dịch nợ không
                            const isDebtPayment = originalTx.tags && (
                                originalTx.tags.includes('#thanh_toan_no') ||
                                originalTx.tags.includes('#tra_gop') ||
                                originalTx.tags.includes('#nop_phat') ||
                                originalTx.tags.includes('#thanh_toan_phi') ||
                                originalTx.tags.includes('#tat_toan_vay') ||
                                originalTx.tags.includes('#tra_no_vay')
                            );

                            // Nếu đã khóa, là giao dịch nợ, và source bị thay đổi thì đánh dấu isSourceFixed
                            if (isLockedTime && isDebtPayment && originalTx.source !== data.source) {
                                data.isSourceFixed = true;
                            }
                        }
                        // ----------------------------------------------

                        if (originalTx.isBrandFixed) {
                            data.isBrandFixed = true;
                        } else {
                            const lockDuration = (originalTx.tags && originalTx.tags.includes('#hoan_tien') ? 1 : 3) * 24 * 60 * 60 * 1000;
                            const isLockedTime = (Date.now() - originalTx.id) > lockDuration;
                            if (isLockedTime && originalTx.brand !== data.brand) {
                                data.isBrandFixed = true;
                            }
                        }

                        // --- KIỂM TRA LÀ GIAO DỊCH TRẢ NỢ ---
                        const isDebtPayment = originalTx.tags && (
                            originalTx.tags.includes('#thanh_toan_no') ||
                            originalTx.tags.includes('#tra_gop') ||
                            originalTx.tags.includes('#nop_phat') ||
                            originalTx.tags.includes('#thanh_toan_phi') ||
                            originalTx.tags.includes('#tat_toan_vay') ||
                            originalTx.tags.includes('#tra_no_vay')
                        );

                        // --- Logic khóa Nguồn tiền (Source) 1 lần ---
                        if (originalTx.isSourceFixed) {
                            data.isSourceFixed = true;
                        } else {
                            const lockDuration = (originalTx.tags && originalTx.tags.includes('#hoan_tien') ? 1 : 3) * 24 * 60 * 60 * 1000;
                            const isLockedTime = (Date.now() - originalTx.id) > lockDuration;

                            // Nếu đã khóa, là nợ, và bị đổi source -> Khóa vĩnh viễn source
                            if (isLockedTime && isDebtPayment && originalTx.source !== data.source) {
                                data.isSourceFixed = true;
                            }
                        }

                        // --- Logic khóa Thời gian (Date) 1 lần ---
                        if (originalTx.isDateFixed) {
                            data.isDateFixed = true;
                        } else {
                            const lockDuration = (originalTx.tags && originalTx.tags.includes('#hoan_tien') ? 1 : 3) * 24 * 60 * 60 * 1000;
                            const isLockedTime = (Date.now() - originalTx.id) > lockDuration;

                            // Nếu đã khóa, là nợ, và bị đổi thời gian -> Khóa vĩnh viễn thời gian
                            if (isLockedTime && isDebtPayment && originalTx.date !== data.date) {
                                data.isDateFixed = true;
                            }
                        }
                    }
                    const idx = app.data.transactions.findIndex(t => t.id == id);
                    app.data.transactions[idx] = data;
                }
            } else {
                app.data.transactions.push(data);
            }

            if (isCashback && discountMoney > 0) {
                const refIdStr = document.getElementById('tx-ref') ? document.getElementById('tx-ref').value.trim() : '';
                const placeContent = "Tiền hoàn giao dịch " + (refIdStr ? refIdStr : new Date(finalDateISO).toLocaleString('vi-VN'));

                const cashbackData = {
                    id: Date.now() + Math.floor(Math.random() * 1000) + 1,
                    type: 'Thu nhập',
                    status: 'paid',
                    amount: discountMoney,
                    discountAmount: 0,
                    discountValue: null,
                    place: placeContent,
                    brand: '',
                    source: `Ngân hàng ${data.source}`, // Nguồn tiền là Ngân hàng + Nguồn tiền giao dịch gốc
                    destination: '',
                    refId: '',
                    isRefFullyLocked: false,
                    orderCode: '',
                    isOrderCodeFullyLocked: false,
                    date: finalDateISO,
                    isUnknownTime: isUnknownTime,
                    tags: '#hoan_tien',
                    isTet: false,
                    is83: false,
                    is304: false
                };
                app.data.transactions.push(cashbackData);
            }

            // Đồng bộ liên kết hai chiều sau khi giao dịch
            // đã được thêm hoặc cập nhật trong CSDL.
            if (
                data.type === 'Chi tiêu' &&
                data.status === 'paid' &&
                data.linkedTransferId !== undefined &&
                data.linkedTransferId !== null &&
                data.linkedTransferId !== ''
            ) {
                app.logic.linkExpenseToTransfer(
                    data.id,
                    data.linkedTransferId
                );
            } else if (
                data.type !== 'Chuyển tiền' ||
                data.status !== 'paid'
            ) {
                // Cancel, đổi loại hoặc đổi trạng thái
                // sẽ gỡ liên kết cũ.
                app.logic.unlinkTransferExpenseLink(
                    data.id
                );
            }

            app.logic.cleanupTransferExpenseLinks({
                save: false
            });

            // [THÊM TẠI ĐÂY] - Sắp xếp lại toàn bộ CSDL gốc trước khi lưu vào Storage
            app.data.transactions.sort(
                (a, b) => app.logic.compareTransactions(a, b)
            );

            if (data.tags && data.tags.includes('#di_vay')) {
                const lenderName = data.place.replace('Vay tiền từ ', '').trim();
                const loan = app.data.loans.find(l =>
                    l.originalAmount === data.amount &&
                    l.lender.toLowerCase() === lenderName.toLowerCase() &&
                    l.status === 'active'
                );

                if (loan) {
                    loan.date = new Date(data.date).toISOString();
                    if (loan.schedule && loan.schedule.length > 0) {
                        const newStartDate = new Date(data.date);
                        loan.schedule.forEach(p => {
                            const nextDate = new Date(newStartDate.getFullYear(), newStartDate.getMonth() + p.period, 7);
                            p.dueDate = nextDate.toLocaleDateString('vi-VN');
                        });
                    }
                    alert(`🔄 Đã đồng bộ ngày vay sang ${new Date(data.date).toLocaleDateString('vi-VN')}\n📅 Lịch trả nợ (Ngày 7) đã được cập nhật lại!`);
                }
            }

            if (app.logic.fixAllTags) {
                app.logic.fixAllTags();
            }

            app.logic.checkAndRolloverZaloCycle({
                save: false,
                notify: true
            });

            app.storage.save();
            app.logic.updateFees();
            app.ui.renderAll();
            app.ui.init();
            document.getElementById('modal-tx').classList.remove('active');

            if (app.ui.transactionModalInterval) {
                clearInterval(app.ui.transactionModalInterval);
                app.ui.transactionModalInterval = null;
            }
        });

        document.getElementById('btn-add-forecast').addEventListener('click', () => {
            const name = document.getElementById('forecast-name').value;
            const amount = Number(document.getElementById('forecast-amount').value);
            if (name && amount) {
                app.data.forecasts.push({ name, amount });
                app.storage.save();
                app.ui.renderAll();
                document.getElementById('forecast-name').value = '';
                document.getElementById('forecast-amount').value = '';
            }
        });

        document.getElementById('guestModeBtn').onclick = () => {
            app.data.configs.guestMode = !app.data.configs.guestMode;
            app.storage.save(); app.ui.renderAll();
        };
        document.getElementById('privateModeBtn').onclick = () => {
            app.security.toggleSetup();
        };

        const hiddenInput = document.getElementById('auth-input-hidden');
        if (hiddenInput) {
            hiddenInput.addEventListener('keyup', (e) => {
                if (e.key >= '0' && e.key <= '9') {
                    app.security.input(parseInt(e.key));
                }
                if (e.key === 'Backspace') {
                    app.security.pin = app.security.pin.slice(0, -1);
                    app.security.renderDots();
                }
                if (e.key === 'Enter') {
                    app.security.submit();
                }
            });
            document.getElementById('security-overlay').addEventListener('click', () => {
                hiddenInput.focus();
            });
        }

        ['gemini-key', 'zalo-review-date'].forEach(id => {
            const input = document.getElementById(id);

            if (!input) return;

            input.addEventListener('change', e => {
                if (
                    id ===
                    'zalo-review-date'
                ) {
                    app.data.configs
                        .zaloReviewDate =
                        e.target.value;

                    /*
                     * Ví dụ:
                     * xét 30/06
                     * -> bắt đầu 01/01.
                     */
                    app.data.configs
                        .zaloRankStartDate =
                        app.logic.shiftZaloDateKey(
                            app.logic.shiftZaloDateKey(
                                e.target.value,
                                0,
                                1
                            ),
                            -6,
                            0
                        );

                    app.logic
                        .checkAndRolloverZaloCycle({
                            save: false,
                            notify: false
                        });

                    app.logic.updateFees();
                    app.ui
                        .renderZaloWidget();
                }

                if (id === 'gemini-key') {
                    if (!app.data.configs.apiKeys) {
                        app.data.configs.apiKeys = {};
                    }

                    app.data.configs.apiKeys.gemini = e.target.value;
                }

                app.storage.save();
            });
        });

        document.getElementById('btn-reset-data').onclick = () => {
            app.ui.popup.confirm(
                "CẢNH BÁO: KHÔI PHỤC CÀI ĐẶT GỐC!\n\nToàn bộ dữ liệu (Giao dịch, Ngân hàng, Ví, Nợ, Mật khẩu...) sẽ bị xóa sạch vĩnh viễn.\nBạn có chắc chắn muốn làm điều này?",
                () => {
                    // 1. TỰ ĐỘNG XÓA SẠCH BỘ NHỚ (Cả LocalStorage và IndexedDB): 
                    const keys = Object.keys(localStorage);
                    for (let key of keys) {
                        if (key.startsWith('fm_')) {
                            localStorage.removeItem(key);
                        }
                    }
                    // Thêm lệnh xóa Database của IndexedDB
                    if (window.indexedDB) {
                        indexedDB.deleteDatabase('FinanceAppDB');
                    }

                    // 2. Reset trạng thái bảo mật trong phiên làm việc hiện tại
                    if (app.security) {
                        app.security.isEnabled = false;
                        app.security.pin = '';
                        app.security.masterKey = '';
                    }

                    // 3. Thông báo và tải lại trang 
                    app.ui.popup.show("✅ Đã khôi phục cài đặt gốc thành công!\nHệ thống sẽ tự động tải lại...", "success");

                    // Tải lại trang sau 1.5s để file 1-data.js khởi tạo lại cấu trúc app.data trống 100%
                    setTimeout(() => {
                        window.location.href = window.location.pathname; // Reload bỏ qua cache / params 
                    }, 1500);
                }
            );
        };

        document.getElementById('debt-list').addEventListener('change', (e) => {
            // Helper function xác định logic mới/cũ
            const useNewLogic = () => {
                const cutoffDate = new Date('2026-01-28T23:59:59');
                return new Date() > cutoffDate;
            };

            if (e.target.matches('.pay-fee-check') || e.target.matches('.pay-min-check') || e.target.matches('.pay-all-check')) {
                e.preventDefault();
                const checkbox = e.target;
                const sourceName = checkbox.dataset.source; // Tên nguồn nợ (VD: Ví Trả Sau MoMo)
                const totalAmount = parseFloat(checkbox.dataset.amount);
                const idsString = checkbox.dataset.ids;

                const isFeeOnly = checkbox.matches('.pay-fee-check');
                const isMinPay = checkbox.matches('.pay-min-check');

                const feeAmount = parseFloat(checkbox.dataset.fee) || 0;
                const penaltyAmount = parseFloat(checkbox.dataset.penalty) || 0;

                let confirmMsg = "";
                if (isFeeOnly) confirmMsg = `Thanh toán PHÍ DỊCH VỤ cho <b>${sourceName}</b>?`;
                else if (isMinPay) confirmMsg = `Thanh toán TỐI THIỂU cho <b>${sourceName}</b>?`;
                else confirmMsg = `Thanh toán TOÀN BỘ cho <b>${sourceName}</b>?`;

                app.ui.popup.confirm(
                    `${confirmMsg}<br>Số tiền: <b>${app.logic.formatCurrency(totalAmount)}</b>`,
                    () => {
                        const paymentDate = app.logic.getPaymentDate();
                        const isNew = useNewLogic();

                        // [LOGIC MỚI] 
                        // Nếu là mới: Source = "Tiền mặt" (Mặc định), Destination = sourceName (Nguồn nợ)
                        // Nếu là cũ: Source = sourceName, Destination = null
                        const txSource = isNew ? "Tiền mặt" : sourceName;
                        const txDest = isNew ? sourceName : null;

                        // 1. Tạo các giao dịch
                        if (isFeeOnly) {
                            app.data.transactions.push({
                                id: Date.now(),
                                type: 'Chi tiêu',
                                place: `Thanh toán Phí/Phí chuyển đổi ${sourceName}`,
                                source: txSource,
                                destination: txDest, // [MỚI]
                                amount: totalAmount,
                                date: paymentDate,
                                tags: '#thanh_toan_phi',
                                status: 'paid'
                            });
                        } else {
                            // Trả Phạt
                            if (penaltyAmount > 0) {
                                app.data.transactions.push({
                                    id: Date.now(),
                                    type: 'Chi tiêu',
                                    place: `Thanh toán Phạt quá hạn ${sourceName}`,
                                    source: txSource,
                                    destination: txDest, // [MỚI]
                                    amount: penaltyAmount,
                                    date: paymentDate,
                                    tags: '#nop_phat',
                                    status: 'paid'
                                });
                            }
                            // Trả Phí
                            if (feeAmount > 0) {
                                app.data.transactions.push({
                                    id: Date.now() + 1,
                                    type: 'Chi tiêu',
                                    place: `Thanh toán Phí/Phí chuyển đổi ${sourceName}`,
                                    source: txSource,
                                    destination: txDest, // [MỚI]
                                    amount: feeAmount,
                                    date: paymentDate,
                                    tags: '#thanh_toan_phi',
                                    status: 'paid'
                                });
                            }
                            // Trả Gốc
                            const principalAmount = totalAmount - feeAmount - penaltyAmount;
                            if (principalAmount > 0) {
                                app.data.transactions.push({
                                    id: Date.now() + 2,
                                    type: 'Chi tiêu',
                                    place: isMinPay ? `Trả tối thiểu Gốc ${sourceName}` : `Trả toàn bộ Gốc ${sourceName}`,
                                    source: txSource,
                                    destination: txDest, // [MỚI]
                                    amount: principalAmount,
                                    date: paymentDate,
                                    tags: '#thanh_toan_no',
                                    status: 'paid'
                                });
                            }
                        }

                        // Gạch nợ cũ
                        if (idsString) {
                            const ids = idsString.split(',').map(Number);
                            app.data.transactions.forEach(t => {
                                if (isFeeOnly) {
                                    if (ids.includes(t.id) && t.tags && t.tags.includes('#phi_dich_vu')) t.status = 'paid';
                                } else {
                                    if (ids.includes(t.id)) t.status = 'paid';
                                }
                            });
                        }

                        // Xử lý dư nợ chuyển tiếp (cho trả tối thiểu)
                        if (isMinPay) {
                            const originalDate = checkbox.dataset.originalDate || new Date().toISOString();
                            const remaining = parseFloat(checkbox.dataset.remaining);
                            if (remaining > 0) {
                                // Dư nợ mới vẫn nằm ở Nguồn nợ cũ (Ví dụ: vẫn nợ trên Ví MoMo)
                                const isZalo = sourceName.toLowerCase().includes('zalo');
                                const newDate = isZalo ? new Date().toISOString() : originalDate;

                                app.data.transactions.push({
                                    id: Date.now() + 3,
                                    type: 'Chi tiêu',
                                    place: `Dư nợ chuyển tiếp (${sourceName})`,
                                    source: sourceName, // Dư nợ thì source vẫn là chính nó
                                    amount: remaining,
                                    date: newDate,
                                    tags: '#du_no_chuyen_tiep',
                                    status: 'pending'
                                });
                            }
                        }

                        app.storage.save();
                        app.ui.renderAll();
                        app.ui.popup.show("✅ Đã thanh toán thành công!", "success");
                    }
                );
                return;
            }

            // --- XỬ LÝ CHECKBOX TRẢ GÓP (PAYMENT-CHECKBOX) ---
            if (e.target.matches('.payment-checkbox')) {
                if (!e.target.checked) return;
                const planId = e.target.getAttribute('data-plan-id');
                const dateKey = e.target.getAttribute('data-date');
                const plan = app.data.installmentPlans[planId];

                if (plan) {
                    const payment = plan.payments.find(p => p.date === dateKey);
                    if (payment) {
                        // Logic ngày 28/1
                        const useNewLogic = new Date() > new Date('2026-01-28T23:59:59');
                        const txSource = useNewLogic ? "Tiền mặt" : plan.source;
                        const txDest = useNewLogic ? plan.source : null;

                        const totalDue =
                            (Number(payment.amount) || 0) +
                            (Number(payment.penaltyAmt) || 0);
                        const alreadyPaid = Number(payment.paidAmount) || 0;
                        const remaining = Math.max(0, totalDue - alreadyPaid);

                        if (remaining <= 0) {
                            payment.paid = true;
                            return;
                        }

                        const paymentDate = app.logic.getPaymentDate();
                        payment.paidAmount = totalDue;
                        payment.paid = true;
                        payment.paidAt = paymentDate;

                        app.data.transactions.push({
                            id: Date.now(),
                            type: 'Chi tiêu',
                            place: `Trả góp ${plan.source} kỳ ${payment.date}`,
                            source: txSource,
                            destination: txDest,
                            amount: remaining,
                            date: paymentDate,
                            tags: '#tra_gop',
                            status: 'paid'
                        });
                        app.storage.save();
                        app.ui.renderAll();
                    }
                }
            }
        });

        // LƯU DỮ LIỆU LÊN FIREBASE CLOUD
        document.getElementById('btn-sync-cloud').onclick = async () => {
            const btn = document.getElementById('btn-sync-cloud');
            const originalContent = btn.innerHTML;

            btn.innerHTML = `
        <div class="menu-icon">
            <i class="fa-solid fa-spinner fa-spin"></i>
        </div>
        <span class="menu-text">Đang lưu...</span>
    `;

            btn.style.pointerEvents = 'none';

            try {
                await app.storage.saveToCloud();
            } catch (error) {
                console.error('Lỗi lưu Cloud:', error);
            } finally {
                btn.innerHTML = originalContent;
                btn.style.pointerEvents = 'auto';
            }
        };

        // TẢI DỮ LIỆU TỪ FIREBASE CLOUD
        document.getElementById('btn-load-cloud').onclick = async () => {
            const btn = document.getElementById('btn-load-cloud');
            const originalContent = btn.innerHTML;

            btn.innerHTML = `
        <div class="menu-icon">
            <i class="fa-solid fa-spinner fa-spin"></i>
        </div>
        <span class="menu-text">Đang tải...</span>
    `;

            btn.style.pointerEvents = 'none';

            try {
                await app.storage.loadFromCloud();
            } catch (error) {
                console.error('Lỗi tải Cloud:', error);
            } finally {
                btn.innerHTML = originalContent;
                btn.style.pointerEvents = 'auto';
            }
        };

        document.getElementById('btn-export-excel').onclick = () => {
            if (!window.jspdf) return app.ui.popup.show("Thư viện PDF đang tải, vui lòng thử lại sau giây lát!", "error");

            const currentMonth = app.data.filter.month;

            // Sử dụng Popup Confirm với 2 luồng (Callback)
            app.ui.popup.confirm(
                `XUẤT DỮ LIỆU PDF\n\nBạn muốn xuất dữ liệu nào?\n\n- <b>ĐỒNG Ý:</b> Xuất TOÀN BỘ lịch sử (Cần PIN).\n- <b>KHÔNG:</b> Chỉ xuất tháng ${currentMonth}.`,

                // LUỒNG 1: XUẤT TOÀN BỘ (Khi bấm Đồng ý)
                () => {
                    if (app.security.isEnabled) {
                        setTimeout(() => {
                            const inputPin = prompt("🔒 BẢO MẬT: Nhập mã PIN để xuất toàn bộ:");
                            if (!inputPin) return;

                            const inputHash = CryptoJS.MD5(inputPin).toString();
                            const savedHash = localStorage.getItem('fm_pin_hash');

                            if (inputHash !== savedHash) {
                                return app.ui.popup.show("❌ MẬT KHẨU SAI! Truy cập bị từ chối.", "error");
                            }
                            // Pass
                            doExportPDF(app.data.transactions, `Finance_Full_Backup_${Date.now()}.pdf`, "TOAN BO LICH SU GIAO DICH");
                        }, 300); // Delay nhỏ để popup cũ đóng hẳn
                    } else {
                        doExportPDF(app.data.transactions, `Finance_Full_Backup_${Date.now()}.pdf`, "TOAN BO LICH SU GIAO DICH");
                    }
                },

                // LUỒNG 2: XUẤT THÁNG NÀY (Khi bấm Không/Hủy)
                () => {
                    const dataToExport = app.logic.getFilteredTxs();
                    if (dataToExport.length === 0) {
                        return app.ui.popup.show(`Tháng ${currentMonth} chưa có giao dịch nào!`, "warning");
                    }
                    doExportPDF(dataToExport, `Finance_Month_${currentMonth}.pdf`, `LICH SU GIAO DICH THANG ${currentMonth.split('-')[1]}/${currentMonth.split('-')[0]}`);
                }
            );

            // Hàm xuất file PDF nội bộ
            const doExportPDF = (data, fileName, titleText) => {
                try {
                    const { jsPDF } = window.jspdf;
                    const doc = new jsPDF('p', 'pt', 'a4'); // Khổ A4 dọc

                    // Hàm bỏ dấu tiếng Việt để PDF không bị lỗi font (Bắt buộc với thư viện mặc định)
                    const removeAccents = (str) => {
                        if (!str) return "";
                        return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D");
                    };

                    // Header File
                    doc.setFontSize(16);
                    doc.setTextColor(15, 23, 42);
                    doc.text(removeAccents(titleText), doc.internal.pageSize.getWidth() / 2, 40, { align: "center" });

                    doc.setFontSize(10);
                    doc.setTextColor(100, 116, 139);
                    doc.text(`Ngay xuat: ${new Date().toLocaleDateString('vi-VN')} ${new Date().toLocaleTimeString('vi-VN')}`, 40, 60);
                    doc.text(`Tong so giao dich: ${data.length}`, 40, 75);

                    // Chuẩn bị dữ liệu bảng (Mô phỏng giống giao diện Web)
                    const tableBody = data
                        .sort((a, b) => app.logic.compareTransactions(a, b))
                        .map(t => {
                            const isInc = t.type === 'Thu nhập';
                            const isTransfer = t.type === 'Chuyển tiền';
                            const isCancelled = t.status === 'cancelled';

                            // 1. Trạng thái
                            let statusText = 'Thanh cong';
                            if (isCancelled) statusText = 'Da huy';
                            else if (t.status === 'planned') statusText = isInc ? 'Se nhan' : 'Se chi';
                            else if (t.status === 'pending') statusText = 'Chua tra';
                            else if (isTransfer) statusText = 'Chuyen khoan';

                            // 2. Nguồn tiền (Có điểm đi & đến nếu là chuyển tiền)
                            let sourceDest = removeAccents(t.source);
                            if (t.destination) {
                                sourceDest += `\n-> ${removeAccents(t.destination)}`;
                            }

                            // 3. Số tiền (Thêm dấu +/- dựa theo loại)
                            const sign = isInc ? '+' : (isTransfer ? '' : '-');
                            const amountStr = `${sign}${new Intl.NumberFormat('vi-VN').format(t.amount)} d`;

                            // 4. Thời gian
                            const dateObj = new Date(t.date);
                            const timeStr = `${dateObj.toLocaleDateString('vi-VN')}\n${dateObj.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}`;

                            // 5. Nội dung (Gộp Brand và Tags thành dòng nhỏ)
                            let contentStr = removeAccents(t.place);
                            const extras = [];
                            if (t.brand) extras.push(removeAccents(t.brand));
                            if (t.tags) extras.push(removeAccents(t.tags));
                            if (extras.length > 0) {
                                contentStr += `\n(${extras.join(' - ')})`;
                            }

                            return [timeStr, contentStr, sourceDest, amountStr, statusText];
                        });

                    // Vẽ bảng (Tự động canh lề và tô màu)
                    doc.autoTable({
                        startY: 90,
                        head: [['Thoi gian', 'Noi dung', 'Nguon tien', 'So tien', 'Trang thai']],
                        body: tableBody,
                        theme: 'grid',
                        headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255], halign: 'center' },
                        styles: { font: "helvetica", fontSize: 9, cellPadding: 5, valign: 'middle' },
                        columnStyles: {
                            0: { cellWidth: 60, halign: 'center' }, // Thời gian
                            1: { cellWidth: 'auto' },               // Nội dung
                            2: { cellWidth: 90 },                   // Nguồn tiền
                            3: { cellWidth: 80, halign: 'right' },  // Số tiền
                            4: { cellWidth: 70, halign: 'center' }  // Trạng thái
                        },
                        didParseCell: function (data) {
                            // Tô màu cho số tiền y hệt như website (xanh, đỏ, xanh dương)
                            if (data.section === 'body' && data.column.index === 3) {
                                const text = data.cell.raw || "";
                                if (text.startsWith('+')) data.cell.styles.textColor = [16, 185, 129]; // Thu (Xanh lá)
                                else if (text.startsWith('-')) data.cell.styles.textColor = [15, 23, 42]; // Chi (Đen nguyên bản)
                                else data.cell.styles.textColor = [2, 132, 199]; // Chuyển tiền (Xanh dương)
                            }
                            // Làm mờ text đối với các giao dịch "Đã hủy"
                            if (data.section === 'body') {
                                const status = data.row.raw[4]; // Cột trạng thái
                                if (status === 'Da huy') {
                                    data.cell.styles.textColor = [148, 163, 184]; // Xám mờ
                                    data.cell.styles.fontStyle = 'italic';
                                }
                            }
                        }
                    });

                    // Lưu file
                    doc.save(fileName);
                    app.ui.popup.show(`✅ Đã xuất file PDF thành công:\n${fileName}`, "success");
                } catch (e) {
                    app.ui.popup.show("Lỗi khi xuất file PDF: " + e.message, "error");
                    console.error(e);
                }
            };
        };
    }
};

// ======================================================
// CÔNG CỤ XUẤT PDF - XUẤT EXCEL - NHẬP EXCEL
// ======================================================

app.dataTools = {
    open() {
        const modal = document.getElementById('modal-data-tools');

        if (modal) {
            modal.classList.add('active');
        }
    },

    close() {
        const modal = document.getElementById('modal-data-tools');

        if (modal) {
            modal.classList.remove('active');
        }
    },

    // Gọi lại chức năng xuất PDF cũ
    runPdf() {
        this.close();

        const oldPdfButton = document.getElementById('btn-export-excel');

        if (!oldPdfButton) {
            return app.ui.popup.show(
                'Không tìm thấy chức năng xuất PDF.',
                'error'
            );
        }

        // Chờ popup đóng rồi mới gọi popup PDF cũ
        setTimeout(() => {
            oldPdfButton.click();
        }, 150);
    },

    exportExcel() {
        if (!window.XLSX) {
            return app.ui.popup.show(
                'Thư viện Excel chưa tải xong. Hãy tải lại trang.',
                'error'
            );
        }

        try {
            const workbook = XLSX.utils.book_new();

            // Chuyển object/array lồng nhau thành chuỗi JSON
            const serializeValue = value => {
                if (value === null || value === undefined) {
                    return '';
                }

                if (value instanceof Date) {
                    return value.toISOString();
                }

                if (typeof value === 'object') {
                    try {
                        return JSON.stringify(value);
                    } catch {
                        return String(value);
                    }
                }

                return value;
            };

            // Chuyển một object thành một dòng Excel
            const serializeRecord = record => {
                if (
                    !record ||
                    typeof record !== 'object' ||
                    Array.isArray(record)
                ) {
                    return {
                        value: serializeValue(record)
                    };
                }

                const row = {};

                Object.entries(record).forEach(([key, value]) => {
                    row[key] = serializeValue(value);
                });

                return row;
            };

            // Chuyển object dạng map thành nhiều dòng
            const mapToRows = (objectMap, idColumn = 'key') => {
                if (!objectMap || typeof objectMap !== 'object') {
                    return [];
                }

                return Object.entries(objectMap).map(([key, value]) => {
                    if (
                        value &&
                        typeof value === 'object' &&
                        !Array.isArray(value)
                    ) {
                        return {
                            [idColumn]: key,
                            ...serializeRecord(value)
                        };
                    }

                    return {
                        [idColumn]: key,
                        value: serializeValue(value)
                    };
                });
            };

            // Tự động thêm sheet và chỉnh độ rộng cột
            const appendSheet = (sheetName, rows) => {
                let safeRows = Array.isArray(rows) ? rows : [];

                if (safeRows.length === 0) {
                    safeRows = [{
                        Thong_bao: 'Không có dữ liệu'
                    }];
                }

                safeRows = safeRows.map(serializeRecord);

                const worksheet = XLSX.utils.json_to_sheet(safeRows);

                const headers = [
                    ...new Set(
                        safeRows.flatMap(row => Object.keys(row))
                    )
                ];

                worksheet['!cols'] = headers.map(header => {
                    let maxLength = Math.max(
                        String(header).length,
                        10
                    );

                    safeRows.forEach(row => {
                        const cellLength = String(
                            row[header] ?? ''
                        ).length;

                        maxLength = Math.max(
                            maxLength,
                            cellLength
                        );
                    });

                    return {
                        // Không để cột JSON rộng quá mức
                        wch: Math.min(maxLength + 2, 50)
                    };
                });

                XLSX.utils.book_append_sheet(
                    workbook,
                    worksheet,
                    sheetName.substring(0, 31)
                );
            };

            const transactions =
                app.data.transactions || [];

            const forecasts =
                app.data.forecasts || [];

            const installmentPlans =
                app.data.installmentPlans || {};

            const createdStatements =
                app.data.createdStatements || {};

            const loans =
                app.data.loans || [];

            const accounts =
                app.data.accounts || [];

            const cashWallets =
                app.data.cashWallets || [];

            /*
             * Loại API key khỏi file Excel.
             * Không nên đưa Gemini key hoặc token bí mật vào file.
             */
            const cleanConfigs = JSON.parse(
                JSON.stringify(app.data.configs || {})
            );

            delete cleanConfigs.apiKeys;

            const debtOverrides =
                cleanConfigs.debtOverrides || {};

            // Tách điều chỉnh nợ thành sheet riêng
            delete cleanConfigs.debtOverrides;

            // ==========================================
            // SHEET 1: TOÀN BỘ GIAO DỊCH
            // Giữ tên Transactions để chức năng nhập cũ vẫn đọc được
            // ==========================================
            appendSheet(
                'Transactions',
                transactions
            );

            // ==========================================
            // SHEET 2: QUẢN LÝ NỢ
            // Các giao dịch chi tiêu chưa thanh toán
            // ==========================================
            const debtRows = transactions
                .filter(transaction => {
                    return (
                        transaction.type === 'Chi tiêu' &&
                        transaction.status === 'pending'
                    );
                })
                .map(transaction => {
                    let statementDate = '';
                    let dueDate = '';

                    try {
                        if (
                            app.logic &&
                            typeof app.logic.getBillingInfo === 'function'
                        ) {
                            const billingInfo =
                                app.logic.getBillingInfo(
                                    transaction.source,
                                    transaction.date
                                );

                            if (billingInfo?.statementDate) {
                                statementDate =
                                    new Date(
                                        billingInfo.statementDate
                                    ).toISOString();
                            }

                            if (billingInfo?.dueDate) {
                                dueDate =
                                    new Date(
                                        billingInfo.dueDate
                                    ).toISOString();
                            }
                        }
                    } catch (error) {
                        console.warn(
                            'Không tính được hạn nợ:',
                            error
                        );
                    }

                    return {
                        id: transaction.id,
                        nguon_no: transaction.source || '',
                        noi_dung: transaction.place || '',
                        thuong_hieu: transaction.brand || '',
                        so_tien: transaction.amount || 0,
                        ngay_giao_dich: transaction.date || '',
                        ngay_sao_ke: statementDate,
                        han_thanh_toan: dueDate,
                        ma_giao_dich: transaction.refId || '',
                        ma_don_hang: transaction.orderCode || '',
                        tags: transaction.tags || '',
                        ghi_chu: transaction.note || '',
                        trang_thai: transaction.status || ''
                    };
                });

            appendSheet(
                'Quan_ly_no',
                debtRows
            );

            // ==========================================
            // SHEET 3: KẾ HOẠCH TRẢ GÓP
            // payments được lưu dưới dạng JSON trong một ô
            // ==========================================
            appendSheet(
                'Tra_gop',
                mapToRows(
                    installmentPlans,
                    'plan_id'
                )
            );

            // ==========================================
            // SHEET 4: SAO KÊ ĐÃ TẠO
            // ==========================================
            appendSheet(
                'Sao_ke',
                mapToRows(
                    createdStatements,
                    'statement_id'
                )
            );

            // ==========================================
            // SHEET 5: QUẢN LÝ VAY
            // ==========================================
            appendSheet(
                'Khoan_vay',
                loans
            );

            // ==========================================
            // SHEET 6: NGÂN HÀNG
            // ==========================================
            appendSheet(
                'Ngan_hang',
                accounts
            );

            // ==========================================
            // SHEET 7: VÍ TIỀN MẶT
            // ==========================================
            appendSheet(
                'Vi_tien_mat',
                cashWallets
            );

            // ==========================================
            // SHEET 8: DỰ BÁO
            // ==========================================
            appendSheet(
                'Du_bao',
                forecasts
            );

            // ==========================================
            // SHEET 9: CẤU HÌNH
            // ==========================================
            const configRows = Object
                .entries(cleanConfigs)
                .map(([key, value]) => ({
                    cau_hinh: key,
                    gia_tri: serializeValue(value)
                }));

            appendSheet(
                'Cau_hinh',
                configRows
            );

            // ==========================================
            // SHEET 10: ĐIỀU CHỈNH NỢ THỦ CÔNG
            // Bao gồm tiền gốc/phạt đã sửa trong Quản lý nợ
            // ==========================================
            appendSheet(
                'Dieu_chinh_no',
                mapToRows(
                    debtOverrides,
                    'nhom_no'
                )
            );

            // ==========================================
            // SHEET 11: BACKUP JSON ĐẦY ĐỦ
            // Chia nhỏ để không vượt giới hạn ký tự của ô Excel
            // ==========================================
            const completeBackup = {
                version: 2,
                exportedAt: new Date().toISOString(),
                transactions,
                configs: cleanConfigs,
                debtOverrides,
                forecasts,
                installmentPlans,
                createdStatements,
                loans,
                accounts,
                cashWallets
            };

            const backupJSON =
                JSON.stringify(completeBackup);

            const chunkSize = 30000;
            const backupChunks = [];

            for (
                let index = 0;
                index < backupJSON.length;
                index += chunkSize
            ) {
                backupChunks.push({
                    phan:
                        Math.floor(index / chunkSize) + 1,
                    noi_dung_json:
                        backupJSON.substring(
                            index,
                            index + chunkSize
                        )
                });
            }

            appendSheet(
                'Backup_JSON',
                backupChunks
            );

            // Tên file
            const now = new Date();

            const dateName = [
                now.getFullYear(),
                String(now.getMonth() + 1).padStart(2, '0'),
                String(now.getDate()).padStart(2, '0'),
                String(now.getHours()).padStart(2, '0'),
                String(now.getMinutes()).padStart(2, '0')
            ].join('-');

            const fileName =
                `FinDash_Full_Backup_${dateName}.xlsx`;

            XLSX.writeFile(
                workbook,
                fileName
            );

            this.close();

            app.ui.popup.show(
                `✅ Đã xuất toàn bộ dữ liệu Excel.<br>` +
                `<b>${fileName}</b><br><br>` +
                `Bao gồm giao dịch, quản lý nợ, trả góp, ` +
                `vay, ngân hàng, ví tiền mặt, sao kê và cấu hình.`,
                'success'
            );
        } catch (error) {
            console.error(
                'Lỗi xuất toàn bộ Excel:',
                error
            );

            app.ui.popup.show(
                `Lỗi khi xuất Excel:<br>${error.message}`,
                'error'
            );
        }
    },

    // --------------------------------------------------
    // NHẬP EXCEL
    // --------------------------------------------------
    importExcel(input) {
        const file = input.files && input.files[0];

        if (!file) return;

        if (!window.XLSX) {
            input.value = '';

            return app.ui.popup.show(
                'Thư viện Excel chưa tải xong. Hãy tải lại trang.',
                'error'
            );
        }

        const reader = new FileReader();

        reader.onload = event => {
            try {
                const workbook = XLSX.read(
                    event.target.result,
                    { type: 'array' }
                );

                const hasSheet = name =>
                    workbook.SheetNames.includes(name);

                const readSheet = name => {
                    if (!hasSheet(name)) return [];

                    const worksheet = workbook.Sheets[name];

                    return XLSX.utils
                        .sheet_to_json(worksheet, { defval: '' })
                        .filter(row => {
                            // Bỏ dòng thông báo được tạo khi sheet trống
                            return !(
                                Object.keys(row).length === 1 &&
                                row.Thong_bao
                            );
                        });
                };

                const parsePossibleJSON = value => {
                    if (typeof value !== 'string') return value;

                    const text = value.trim();

                    if (!text) return '';

                    if (
                        !text.startsWith('{') &&
                        !text.startsWith('[')
                    ) {
                        return value;
                    }

                    try {
                        return JSON.parse(text);
                    } catch {
                        return value;
                    }
                };

                const parseConfigValue = value => {
                    if (typeof value !== 'string') return value;

                    const text = value.trim();

                    if (!text) return '';

                    try {
                        if (
                            text.startsWith('{') ||
                            text.startsWith('[') ||
                            text === 'true' ||
                            text === 'false' ||
                            text === 'null' ||
                            /^-?\d+(\.\d+)?$/.test(text)
                        ) {
                            return JSON.parse(text);
                        }
                    } catch {
                        // Giữ nguyên chuỗi
                    }

                    return value;
                };

                const parseNumber = value => {
                    if (typeof value === 'number') {
                        return Number.isFinite(value) ? value : 0;
                    }

                    const cleaned = String(value ?? '')
                        .replace(/[^\d.-]/g, '');

                    const number = Number(cleaned);

                    return Number.isFinite(number) ? number : 0;
                };

                const parseBoolean = value => {
                    if (typeof value === 'boolean') return value;

                    return [
                        'true',
                        '1',
                        'yes',
                        'có',
                        'co',
                        'x'
                    ].includes(
                        String(value ?? '')
                            .trim()
                            .toLowerCase()
                    );
                };

                const parseDate = value => {
                    if (
                        typeof value === 'number' &&
                        XLSX.SSF &&
                        XLSX.SSF.parse_date_code
                    ) {
                        const excelDate =
                            XLSX.SSF.parse_date_code(value);

                        if (excelDate) {
                            return new Date(
                                excelDate.y,
                                excelDate.m - 1,
                                excelDate.d,
                                excelDate.H || 12,
                                excelDate.M || 0,
                                excelDate.S || 0
                            ).toISOString();
                        }
                    }

                    const date = new Date(value);

                    if (!Number.isNaN(date.getTime())) {
                        return date.toISOString();
                    }

                    return new Date().toISOString();
                };

                const parseRow = row => {
                    const result = {};

                    Object.entries(row || {}).forEach(
                        ([rawKey, rawValue]) => {
                            const key = String(rawKey).trim();

                            if (!key) return;

                            result[key] =
                                parsePossibleJSON(rawValue);
                        }
                    );

                    return result;
                };

                const isPlainObject = value => {
                    return (
                        value !== null &&
                        typeof value === 'object' &&
                        !Array.isArray(value)
                    );
                };

                const isEmptyImportedValue = value => {
                    return (
                        value === '' ||
                        value === null ||
                        value === undefined
                    );
                };

                /*
                 * Excel được ưu tiên nếu có giá trị.
                 * Ô trống trong Excel không được xóa dữ liệu cũ.
                 */
                const mergeImportedData = (currentValue, importedValue) => {
                    if (isEmptyImportedValue(importedValue)) {
                        return currentValue;
                    }

                    if (Array.isArray(importedValue)) {
                        return JSON.parse(
                            JSON.stringify(importedValue)
                        );
                    }

                    if (isPlainObject(importedValue)) {
                        const result = isPlainObject(currentValue)
                            ? { ...currentValue }
                            : {};

                        Object.entries(importedValue).forEach(
                            ([key, value]) => {
                                if (isEmptyImportedValue(value)) {
                                    return;
                                }

                                result[key] = mergeImportedData(
                                    result[key],
                                    value
                                );
                            }
                        );

                        return result;
                    }

                    return importedValue;
                };

                /*
                 * Chuẩn hóa object trước khi so sánh.
                 * Không phụ thuộc thứ tự thuộc tính trong object.
                 */
                const normalizeForCompare = value => {
                    if (
                        value === undefined ||
                        value === null ||
                        value === ''
                    ) {
                        return null;
                    }

                    if (Array.isArray(value)) {
                        return value.map(normalizeForCompare);
                    }

                    if (isPlainObject(value)) {
                        return Object.keys(value)
                            .sort()
                            .reduce((result, key) => {
                                result[key] =
                                    normalizeForCompare(value[key]);

                                return result;
                            }, {});
                    }

                    return value;
                };

                const isSameData = (firstValue, secondValue) => {
                    return JSON.stringify(
                        normalizeForCompare(firstValue)
                    ) === JSON.stringify(
                        normalizeForCompare(secondValue)
                    );
                };

                /*
                 * Gộp dữ liệu dạng mảng:
                 * - Trùng và giống: bỏ qua.
                 * - Trùng khóa nhưng khác: cập nhật.
                 * - Chưa tồn tại: thêm.
                 */
                const mergeArray = (
                    currentData,
                    importedData,
                    getKey
                ) => {
                    const result = Array.isArray(currentData)
                        ? [...currentData]
                        : [];

                    const indexMap = new Map();

                    result.forEach((item, index) => {
                        const key = getKey(item);

                        if (
                            key !== null &&
                            key !== undefined &&
                            key !== ''
                        ) {
                            indexMap.set(String(key), index);
                        }
                    });

                    let added = 0;
                    let updated = 0;
                    let skipped = 0;

                    (Array.isArray(importedData)
                        ? importedData
                        : []
                    ).forEach(importedItem => {
                        const key = getKey(importedItem);

                        if (
                            key !== null &&
                            key !== undefined &&
                            key !== '' &&
                            indexMap.has(String(key))
                        ) {
                            const index =
                                indexMap.get(String(key));

                            const currentItem =
                                result[index];

                            const mergedItem =
                                mergeImportedData(
                                    currentItem,
                                    importedItem
                                );

                            if (
                                isSameData(
                                    currentItem,
                                    mergedItem
                                )
                            ) {
                                // Có trên web rồi và không thay đổi
                                skipped++;
                                return;
                            }

                            // Có cùng ID nhưng Excel có dữ liệu khác
                            result[index] = mergedItem;
                            updated++;

                            return;
                        }

                        /*
                         * Trường hợp không có ID:
                         * kiểm tra toàn bộ nội dung để tránh nhập trùng.
                         */
                        const duplicated = result.some(
                            currentItem =>
                                isSameData(
                                    currentItem,
                                    importedItem
                                )
                        );

                        if (duplicated) {
                            skipped++;
                            return;
                        }

                        const newItem =
                            mergeImportedData(
                                undefined,
                                importedItem
                            );

                        result.push(newItem);

                        if (
                            key !== null &&
                            key !== undefined &&
                            key !== ''
                        ) {
                            indexMap.set(
                                String(key),
                                result.length - 1
                            );
                        }

                        added++;
                    });

                    return {
                        data: result,
                        added,
                        updated,
                        skipped
                    };
                };

                /*
                 * Gộp dữ liệu dạng object/map:
                 * dùng cho trả góp, sao kê, cấu hình,
                 * điều chỉnh nợ...
                 */
                const mergeObjectMap = (
                    currentMap,
                    importedMap
                ) => {
                    const result = isPlainObject(currentMap)
                        ? { ...currentMap }
                        : {};

                    let added = 0;
                    let updated = 0;
                    let skipped = 0;

                    if (!isPlainObject(importedMap)) {
                        return {
                            data: result,
                            added,
                            updated,
                            skipped
                        };
                    }

                    Object.entries(importedMap).forEach(
                        ([key, importedValue]) => {
                            if (
                                !Object.prototype.hasOwnProperty.call(
                                    result,
                                    key
                                )
                            ) {
                                result[key] =
                                    mergeImportedData(
                                        undefined,
                                        importedValue
                                    );

                                added++;
                                return;
                            }

                            const currentValue = result[key];

                            const mergedValue =
                                mergeImportedData(
                                    currentValue,
                                    importedValue
                                );

                            if (
                                isSameData(
                                    currentValue,
                                    mergedValue
                                )
                            ) {
                                skipped++;
                                return;
                            }

                            result[key] = mergedValue;
                            updated++;
                        }
                    );

                    return {
                        data: result,
                        added,
                        updated,
                        skipped
                    };
                };

                const normalizeTransaction = (
                    rawRow,
                    index = 0
                ) => {
                    const transaction = parseRow(rawRow);

                    const numberFields = [
                        'id',
                        'amount',
                        'discountAmount',
                        'discountValue',
                        'tempExtraFee'
                    ];

                    numberFields.forEach(field => {
                        if (
                            transaction[field] !== undefined &&
                            transaction[field] !== ''
                        ) {
                            transaction[field] =
                                parseNumber(transaction[field]);
                        }
                    });

                    const booleanFields = [
                        'isUnknownTime',
                        'isCashback',
                        'isTet',
                        'is83',
                        'is304',
                        'isRefFullyLocked',
                        'isOrderCodeFullyLocked',
                        'excludeFromBudget',
                        'excludeFromDashboard',
                        'skipZalo',
                        'isDeferred',
                        'isSourceFixed',
                        'isDateFixed',
                        'isBrandFixed'
                    ];

                    booleanFields.forEach(field => {
                        if (
                            transaction[field] !== undefined &&
                            transaction[field] !== ''
                        ) {
                            transaction[field] =
                                parseBoolean(transaction[field]);
                        }
                    });

                    if (!transaction.id) {
                        transaction.id =
                            Date.now() + index;
                    }

                    transaction.amount =
                        Number(transaction.amount) || 0;

                    transaction.type =
                        transaction.type || 'Chi tiêu';

                    transaction.status =
                        transaction.status || 'paid';

                    transaction.place =
                        transaction.place || 'Nhập từ Excel';

                    transaction.source =
                        transaction.source || 'Không xác định';

                    transaction.tags =
                        transaction.tags || '';

                    if (transaction.date) {
                        transaction.date =
                            parseDate(transaction.date);
                    } else {
                        transaction.date =
                            new Date().toISOString();
                    }

                    return transaction;
                };

                const rowsToMap = (
                    rows,
                    primaryKey
                ) => {
                    const result = {};

                    rows.forEach((rawRow, index) => {
                        const row = parseRow(rawRow);

                        const key =
                            row[primaryKey] ??
                            row.id ??
                            row.key ??
                            index;

                        delete row[primaryKey];

                        result[String(key)] = row;
                    });

                    return result;
                };

                const configRowsToObject = rows => {
                    const result = {};

                    rows.forEach(rawRow => {
                        const row = parseRow(rawRow);

                        const key =
                            row.cau_hinh ??
                            row.key;

                        if (!key) return;

                        const value =
                            row.gia_tri ??
                            row.value ??
                            '';

                        result[String(key)] =
                            parseConfigValue(value);
                    });

                    return result;
                };

                const debtRowsToTransactions = rows => {
                    return rows.map((rawRow, index) => {
                        const row = parseRow(rawRow);

                        return normalizeTransaction({
                            id:
                                row.id ||
                                Date.now() + index,

                            type: 'Chi tiêu',

                            status:
                                row.trang_thai ||
                                row.status ||
                                'pending',

                            amount:
                                row.so_tien ??
                                row.amount ??
                                0,

                            place:
                                row.noi_dung ||
                                row.place ||
                                'Khoản nợ',

                            brand:
                                row.thuong_hieu ||
                                row.brand ||
                                '',

                            source:
                                row.nguon_no ||
                                row.source ||
                                'Không xác định',

                            destination:
                                row.destination || '',

                            date:
                                row.ngay_giao_dich ||
                                row.date ||
                                new Date().toISOString(),

                            refId:
                                row.ma_giao_dich ||
                                row.refId ||
                                '',

                            orderCode:
                                row.ma_don_hang ||
                                row.orderCode ||
                                '',

                            tags:
                                row.tags || '',

                            note:
                                row.ghi_chu ||
                                row.note ||
                                ''
                        }, index);
                    });
                };

                // ==========================================
                // 1. ĐỌC BACKUP JSON ĐẦY ĐỦ
                // ==========================================
                let importedData = {};

                const backupRows =
                    readSheet('Backup_JSON');

                if (backupRows.length > 0) {
                    const backupText = backupRows
                        .sort((a, b) => {
                            return (
                                parseNumber(a.phan) -
                                parseNumber(b.phan)
                            );
                        })
                        .map(row => {
                            return String(
                                row.noi_dung_json || ''
                            );
                        })
                        .join('');

                    if (backupText) {
                        importedData =
                            JSON.parse(backupText);
                    }
                }

                /*
                 * Các sheet riêng được đọc sau Backup_JSON.
                 * Vì vậy nếu người dùng sửa trực tiếp một sheet,
                 * dữ liệu sheet đó sẽ được ưu tiên.
                 */

                // ==========================================
                // 2. GIAO DỊCH
                // ==========================================
                if (hasSheet('Transactions')) {
                    importedData.transactions =
                        readSheet('Transactions')
                            .map(normalizeTransaction);
                }

                // Sheet Quản lý nợ cập nhật lại các giao dịch pending
                if (hasSheet('Quan_ly_no')) {
                    const debtTransactions =
                        debtRowsToTransactions(
                            readSheet('Quan_ly_no')
                        );

                    const mergedDebts = mergeArray(
                        importedData.transactions || [],
                        debtTransactions,
                        transaction => transaction.id
                    );

                    importedData.transactions =
                        mergedDebts.data;
                }

                // ==========================================
                // 3. TRẢ GÓP
                // ==========================================
                if (hasSheet('Tra_gop')) {
                    importedData.installmentPlans =
                        rowsToMap(
                            readSheet('Tra_gop'),
                            'plan_id'
                        );
                }

                // ==========================================
                // 4. SAO KÊ
                // ==========================================
                if (hasSheet('Sao_ke')) {
                    importedData.createdStatements =
                        rowsToMap(
                            readSheet('Sao_ke'),
                            'statement_id'
                        );
                }

                // ==========================================
                // 5. KHOẢN VAY
                // ==========================================
                if (hasSheet('Khoan_vay')) {
                    importedData.loans =
                        readSheet('Khoan_vay')
                            .map(parseRow);
                }

                // ==========================================
                // 6. NGÂN HÀNG
                // ==========================================
                if (hasSheet('Ngan_hang')) {
                    importedData.accounts =
                        readSheet('Ngan_hang')
                            .map(parseRow);
                }

                // ==========================================
                // 7. VÍ TIỀN MẶT
                // ==========================================
                if (hasSheet('Vi_tien_mat')) {
                    importedData.cashWallets =
                        readSheet('Vi_tien_mat')
                            .map(parseRow);
                }

                // ==========================================
                // 8. DỰ BÁO
                // ==========================================
                if (hasSheet('Du_bao')) {
                    importedData.forecasts =
                        readSheet('Du_bao')
                            .map(parseRow);
                }

                // ==========================================
                // 9. CẤU HÌNH
                // ==========================================
                if (hasSheet('Cau_hinh')) {
                    importedData.configs =
                        mergeImportedData(
                            importedData.configs || {},
                            configRowsToObject(
                                readSheet('Cau_hinh')
                            )
                        );
                }

                // ==========================================
                // 10. ĐIỀU CHỈNH NỢ
                // ==========================================
                if (hasSheet('Dieu_chinh_no')) {
                    importedData.debtOverrides =
                        rowsToMap(
                            readSheet('Dieu_chinh_no'),
                            'nhom_no'
                        );
                }

                /*
                 * Hỗ trợ file Excel cũ chỉ có một sheet.
                 * Sheet đầu tiên sẽ được hiểu là Transactions.
                 */
                const recognizedSheets = [
                    'Transactions',
                    'Quan_ly_no',
                    'Tra_gop',
                    'Sao_ke',
                    'Khoan_vay',
                    'Ngan_hang',
                    'Vi_tien_mat',
                    'Du_bao',
                    'Cau_hinh',
                    'Dieu_chinh_no',
                    'Backup_JSON'
                ];

                const hasRecognizedSheet =
                    workbook.SheetNames.some(name =>
                        recognizedSheets.includes(name)
                    );

                if (
                    !hasRecognizedSheet &&
                    workbook.SheetNames.length > 0
                ) {
                    const firstSheet =
                        workbook.Sheets[
                        workbook.SheetNames[0]
                        ];

                    importedData.transactions =
                        XLSX.utils
                            .sheet_to_json(
                                firstSheet,
                                { defval: '' }
                            )
                            .map(normalizeTransaction);
                }

                if (
                    !importedData ||
                    Object.keys(importedData).length === 0
                ) {
                    throw new Error(
                        'File Excel không có dữ liệu FinDash hợp lệ.'
                    );
                }

                // Không cho file Excel thay thế Gemini API Key
                const currentApiKeys =
                    app.data.configs?.apiKeys || {};

                const currentDebtOverrides =
                    app.data.configs?.debtOverrides || {};

                let totalAdded = 0;
                let totalUpdated = 0;
                let totalSkipped = 0;

                // ==========================================
                // CẬP NHẬT GIAO DỊCH
                // ==========================================
                if (
                    Array.isArray(
                        importedData.transactions
                    )
                ) {
                    const transactionResult =
                        mergeArray(
                            app.data.transactions || [],
                            importedData.transactions,
                            transaction =>
                                transaction.id
                        );

                    app.data.transactions =
                        transactionResult.data.sort(
                            (a, b) => app.logic.compareTransactions(a, b)
                        );

                    totalAdded +=
                        transactionResult.added;

                    totalUpdated +=
                        transactionResult.updated;

                    totalSkipped +=
                        transactionResult.skipped;
                }

                // ==========================================
                // CẬP NHẬT DỰ BÁO
                // ==========================================
                if (
                    Array.isArray(
                        importedData.forecasts
                    )
                ) {
                    const result = mergeArray(
                        app.data.forecasts || [],
                        importedData.forecasts,
                        item =>
                            item.id ??
                            item.name ??
                            null
                    );

                    app.data.forecasts = result.data;
                    totalAdded += result.added;
                    totalUpdated += result.updated;
                    totalSkipped += result.skipped;
                }

                // ==========================================
                // CẬP NHẬT KHOẢN VAY
                // ==========================================
                if (Array.isArray(importedData.loans)) {
                    const result = mergeArray(
                        app.data.loans || [],
                        importedData.loans,
                        loan => {
                            if (loan.id !== undefined) {
                                return `id:${loan.id}`;
                            }

                            return [
                                loan.lender || '',
                                loan.createdDate ||
                                loan.date ||
                                '',
                                loan.originalAmount ||
                                loan.amount ||
                                ''
                            ].join('|');
                        }
                    );

                    app.data.loans = result.data;
                    totalAdded += result.added;
                    totalUpdated += result.updated;
                    totalSkipped += result.skipped;
                }

                // ==========================================
                // CẬP NHẬT NGÂN HÀNG
                // ==========================================
                if (
                    Array.isArray(
                        importedData.accounts
                    )
                ) {
                    const result = mergeArray(
                        app.data.accounts || [],
                        importedData.accounts,
                        account =>
                            account.id ??
                            account.accountId ??
                            account.bankName ??
                            account.name ??
                            null
                    );

                    app.data.accounts = result.data;
                    totalAdded += result.added;
                    totalUpdated += result.updated;
                    totalSkipped += result.skipped;
                }

                // ==========================================
                // CẬP NHẬT VÍ TIỀN MẶT
                // ==========================================
                if (
                    Array.isArray(
                        importedData.cashWallets
                    )
                ) {
                    const result = mergeArray(
                        app.data.cashWallets || [],
                        importedData.cashWallets,
                        wallet =>
                            wallet.id ??
                            wallet.walletId ??
                            wallet.name ??
                            null
                    );

                    app.data.cashWallets = result.data;
                    totalAdded += result.added;
                    totalUpdated += result.updated;
                    totalSkipped += result.skipped;
                }

                // ==========================================
                // CẬP NHẬT TRẢ GÓP
                // ==========================================
                const importedInstallments =
                    importedData.installmentPlans ||
                    importedData.installments;

                if (isPlainObject(importedInstallments)) {
                    const installmentResult =
                        mergeObjectMap(
                            app.data.installmentPlans || {},
                            importedInstallments
                        );

                    app.data.installmentPlans =
                        installmentResult.data;

                    totalAdded += installmentResult.added;
                    totalUpdated += installmentResult.updated;
                    totalSkipped += installmentResult.skipped;
                }

                // ==========================================
                // CẬP NHẬT SAO KÊ
                // ==========================================
                const importedStatements =
                    importedData.createdStatements ||
                    importedData.statements;

                if (isPlainObject(importedStatements)) {
                    const statementResult =
                        mergeObjectMap(
                            app.data.createdStatements || {},
                            importedStatements
                        );

                    app.data.createdStatements =
                        statementResult.data;

                    totalAdded += statementResult.added;
                    totalUpdated += statementResult.updated;
                    totalSkipped += statementResult.skipped;
                }

                // ==========================================
                // CẬP NHẬT CẤU HÌNH
                // ==========================================
                const importedConfigs = {
                    ...(importedData.configs || {})
                };

                const overridesInsideConfigs =
                    importedConfigs.debtOverrides || {};

                delete importedConfigs.apiKeys;
                delete importedConfigs.debtOverrides;

                const configResult =
                    mergeObjectMap(
                        app.data.configs || {},
                        importedConfigs
                    );

                app.data.configs =
                    configResult.data;

                // Không cho Excel ghi đè API Key trên máy
                app.data.configs.apiKeys =
                    currentApiKeys;

                totalAdded += configResult.added;
                totalUpdated += configResult.updated;
                totalSkipped += configResult.skipped;

                // Cập nhật phần chỉnh sửa nợ thủ công
                const importedOverrides =
                    mergeImportedData(
                        overridesInsideConfigs,
                        importedData.debtOverrides || {}
                    );

                const overrideResult =
                    mergeObjectMap(
                        currentDebtOverrides,
                        importedOverrides
                    );

                app.data.configs.debtOverrides =
                    overrideResult.data;

                totalAdded += overrideResult.added;
                totalUpdated += overrideResult.updated;
                totalSkipped += overrideResult.skipped;

                // Sửa lại tag nếu hệ thống có hàm này
                if (
                    app.logic.fixAllTags
                ) {
                    app.logic.fixAllTags();
                }

                /*
                 * Xử lý ngày xét hạng và
                 * nâng hạng ngay sau khi
                 * giao dịch được lưu.
                 */
                app.logic
                    .checkAndRolloverZaloCycle({
                        save: false,
                        notify: true
                    });

                app.storage.save();
                app.logic.updateFees();

                // Cập nhật giao diện
                app.ui.init();
                app.ui.renderAll();

                this.close();

                app.ui.popup.show(
                    `✅ Đã kiểm tra và nhập dữ liệu Excel!<br><br>` +
                    `➕ Thêm mới: <b>${totalAdded}</b><br>` +
                    `🔄 Cập nhật khác biệt: <b>${totalUpdated}</b><br>` +
                    `⏭️ Bỏ qua do đã giống: <b>${totalSkipped}</b><br><br>` +
                    `Dữ liệu giống hoàn toàn sẽ không bị nhập lại.`,
                    'success'
                );
            } catch (error) {
                console.error(
                    'Lỗi nhập toàn bộ Excel:',
                    error
                );

                app.ui.popup.show(
                    `Không thể nhập Excel:<br>${error.message}`,
                    'error'
                );
            } finally {
                // Cho phép chọn lại cùng một file
                input.value = '';
            }
        };

        reader.onerror = () => {
            input.value = '';

            app.ui.popup.show(
                'Không thể đọc file Excel.',
                'error'
            );
        };

        reader.readAsArrayBuffer(file);
    }
};

document.addEventListener('DOMContentLoaded', () => app.init());

document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
});
// --- NÂNG CẤP TRÍ TUỆ AI (Context-Aware Financial Advisor) ---
document.getElementById('btn-ask-gemini').addEventListener('click', async () => {
    const inputEl = document.getElementById('gemini-prompt');
    const chatLog = document.getElementById('chat-log');
    const question = inputEl.value.trim();
    const apiKey = app.data.configs.apiKeys.gemini;

    if (!question) return;
    if (!apiKey) return app.ui.popup.show("⚠️ Chưa nhập Gemini API Key trong Cấu hình!", "error");

    // 1. Hiển thị câu hỏi của User
    const userMsgHTML = `
        <div class="chat-msg user">
            <div class="chat-bubble">${question}</div>
        </div>`;
    chatLog.insertAdjacentHTML('beforeend', userMsgHTML);
    inputEl.value = '';
    chatLog.scrollTop = chatLog.scrollHeight;

    // 2. Hiển thị Loading
    const loadingId = 'loading-' + Date.now();
    const loadingHTML = `
        <div id="${loadingId}" class="chat-msg ai">
            <div class="ai-avatar"><i class="fa-solid fa-robot"></i></div>
            <div class="chat-bubble">
                <div class="typing-indicator">
                    <div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>
                </div>
            </div>
        </div>`;
    chatLog.insertAdjacentHTML('beforeend', loadingHTML);
    chatLog.scrollTop = chatLog.scrollHeight;

    // --- BƯỚC QUAN TRỌNG: TỔNG HỢP DỮ LIỆU TÀI CHÍNH NÂNG CAO ---
    const currentMonth = app.data.filter.month;
    const txs = app.logic.getFilteredTxs();

    const income = app.logic.getActualIncomeTotal(currentMonth);
    const realExpenses = app.logic.getRealCashExpenseTransactions({
        month: currentMonth
    });
    const totalExpense = realExpenses.reduce(
        (sum, t) => sum + (Number(t.amount) || 0),
        0
    );
    const realCashBalance = app.logic.getRealCashBalance(currentMonth);
    const limitState = app.logic.getMonthlyLimitState(currentMonth);

    const upcomingData = app.logic.getUpcomingDebts(currentMonth);
    const upcomingDebt = Number(upcomingData.budgetTotal) || 0;
    const cashAfterDebtReserve = realCashBalance - upcomingDebt;
    const debtItems = upcomingData.items
        .map(i => `${i.name} (${app.logic.formatCurrency((Number(i.amount) || 0) + (Number(i.penalty) || 0))})`)
        .join(', ');

    const limit = limitState.configured;
    const remainingBudget = limitState.remaining;
    const burnRate = limit > 0
        ? Math.round(limitState.percent)
        : (income > 0 ? Math.round((totalExpense / income) * 100) : 0);

    // Mở rộng Top 5 khoản tiêu thực trả kèm Tag để AI phân tích thói quen
    const topSpending = realExpenses.slice().sort((a, b) => b.amount - a.amount).slice(0, 5)
        .map(t => `- ${t.place} (${t.tags || 'Khác'}): ${app.logic.formatCurrency(t.amount)}`).join('\n');

    // Dữ liệu bối cảnh gửi cho AI
    const financialContext = `
    [DỮ LIỆU TÀI CHÍNH THÁNG ${currentMonth}]
    - Tổng Thu Nhập chính thức: ${app.logic.formatCurrency(income)}
    - Tổng Chi Tiêu làm giảm tiền thực: ${app.logic.formatCurrency(totalExpense)}
    - Tiền thực còn lại: ${app.logic.formatCurrency(realCashBalance)}
    - Tiền thực sau khi dự phòng nợ: ${app.logic.formatCurrency(cashAfterDebtReserve)}
    ${limit > 0 ? `- Hạn mức tháng: ${app.logic.formatCurrency(limit)} | Đã dùng: ${app.logic.formatCurrency(limitState.used)} (${burnRate}%) | Còn: ${app.logic.formatCurrency(remainingBudget)}${limitState.over > 0 ? ` | Vượt: ${app.logic.formatCurrency(limitState.over)}` : ''}` : `- Chưa thiết lập hạn mức tháng.`}
    - Nợ Sắp Phải Trả: ${app.logic.formatCurrency(upcomingDebt)} (${debtItems || 'Không có khoản nợ nào'})
    
    [TOP 5 KHOẢN CHI LỚN NHẤT THÁNG NÀY]
    ${topSpending || 'Chưa có khoản chi tiêu nào đáng kể.'}
    
    [CÂU HỎI CỦA TÔI]: 
    "${question}"
    `;

    // System Instruction: Ép AI nhập vai và tư duy phân tích
    const systemInstruction = `Bạn là FinDash AI - trợ lý tài chính cá nhân thông minh, sắc bén và hơi "xéo xắt" (hài hước, châm biếm nhẹ nhàng). 
    QUY TẮC TRẢ LỜI:
    1. Trả lời thẳng vào câu hỏi của người dùng.
    2. Nếu thấy tỷ lệ chi tiêu (Burn rate) > 80%, hãy dùng lời lẽ gay gắt, mỉa mai để cảnh báo nguy cơ cháy túi.
    3. Nếu Số dư < Nợ sắp trả, hãy khẩn thiết nhắc nhở họ chuẩn bị tiền trả nợ ngay lập tức.
    4. Nhìn vào "Top 5 khoản chi lớn nhất" để đánh giá thói quen tiêu dùng (VD: "Tiêu quá nhiều vào ăn nhậu/mua sắm rồi đấy").
    5. Đưa ra 1 lời khuyên thực tế nhất (hành động cụ thể).
    6. Ngắn gọn, súc tích (dưới 150 từ). Sử dụng bullet point và emoji để dễ đọc.`;

    // 3. Gọi API Gemini với cấu trúc thông minh
    try {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                systemInstruction: {
                    parts: [{ text: systemInstruction }]
                },
                contents: [
                    { parts: [{ text: financialContext }] }
                ]
            })
        });

        if (!res.ok) throw new Error(`Lỗi Server: ${res.statusText}`);

        const data = await res.json();
        const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || "Gemini đang bận đếm tiền, thử lại sau nhé!";

        const loadingEl = document.getElementById(loadingId);
        if (loadingEl) loadingEl.remove();

        const formattedReply = reply.replace(/\n/g, '<br>');

        const aiMsgHTML = `
            <div class="chat-msg ai">
                <div class="ai-avatar"><i class="fa-solid fa-robot"></i></div>
                <div class="chat-bubble">${formattedReply}</div>
            </div>`;
        chatLog.insertAdjacentHTML('beforeend', aiMsgHTML);

    } catch (e) {
        const loadingEl = document.getElementById(loadingId);
        if (loadingEl) loadingEl.remove();

        chatLog.insertAdjacentHTML('beforeend', `<div class="chat-msg ai"><div class="chat-bubble text-danger">Lỗi kết nối AI: ${e.message}</div></div>`);
    }

    chatLog.scrollTop = chatLog.scrollHeight;
});

// Sự kiện nhấn Enter để gửi
document.getElementById('gemini-prompt').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') document.getElementById('btn-ask-gemini').click();
});

// ==========================================
// THÊM ĐOẠN NÀY VÀO CUỐI FILE 6-main.js
// ==========================================

// 1. Đảm bảo object app.ui tồn tại để không bị lỗi
window.app = window.app || {};
window.app.ui = window.app.ui || {};

// 2. Điều khiển menu mobile thống nhất
app.ui.toggleMobileMenu = function (forceOpen) {
    const sidebar = document.getElementById('sidebar');
    const backdrop = document.getElementById('mobile-backdrop');
    const toggleButtons = document.querySelectorAll('.mobile-menu-toggle');

    if (!sidebar) return false;

    const shouldOpen = typeof forceOpen === 'boolean'
        ? forceOpen
        : !sidebar.classList.contains('active');

    // Trên mobile luôn mở sidebar ở trạng thái đầy đủ.
    if (shouldOpen) sidebar.classList.remove('collapsed');

    sidebar.classList.toggle('active', shouldOpen);
    document.body.classList.toggle('mobile-menu-open', shouldOpen);

    if (backdrop) {
        // Xóa style inline của phiên bản cũ để CSS quản lý.
        backdrop.style.removeProperty('display');
        backdrop.classList.toggle('active', shouldOpen);
        backdrop.setAttribute('aria-hidden', String(!shouldOpen));
    }

    toggleButtons.forEach((button) => {
        button.setAttribute('aria-expanded', String(shouldOpen));
        button.setAttribute(
            'aria-label',
            shouldOpen ? 'Đóng menu' : 'Mở menu'
        );
    });

    return shouldOpen;
};

// Đóng menu khi chuyển sang màn hình máy tính.
window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        app.ui.toggleMobileMenu(false);
    }
}, { passive: true });

// Nhấn Escape để đóng menu.
document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && window.innerWidth <= 768) {
        app.ui.toggleMobileMenu(false);
    }
});

// Chạm vào nền tối để đóng menu.
document.addEventListener('DOMContentLoaded', () => {
    const backdrop = document.getElementById('mobile-backdrop');

    if (backdrop) {
        backdrop.setAttribute('aria-hidden', 'true');
        backdrop.addEventListener('click', () => {
            app.ui.toggleMobileMenu(false);
        });
    }
});
// ==========================================
// THUẬT TOÁN ĐO KHOẢNG CÁCH CHỈNH SỬA (MỚI)
// ==========================================
const getEditDistance = (a, b) => {
    if (a.length === 0) return b.length;
    if (b.length === 0) return a.length;
    const matrix = [];
    for (let i = 0; i <= b.length; i++) matrix[i] = [i];
    for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            if (b.charAt(i - 1) === a.charAt(j - 1)) matrix[i][j] = matrix[i - 1][j - 1];
            else matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, Math.min(matrix[i][j - 1] + 1, matrix[i - 1][j] + 1));
        }
    }
    return matrix[b.length][a.length];
};

const handleEditLimit = (e, originalId, errorId, lockFlagId, typeName) => {
    const origVal = document.getElementById(originalId).value.trim();
    const currentVal = e.target.value.trim();
    const errorEl = document.getElementById(errorId);
    const lockFlagEl = document.getElementById(lockFlagId);
    const txSubmitBtn = document.querySelector('#form-tx button[type="submit"]');

    let is3DaysOld = false;
    const txIdStr = document.getElementById('tx-id') ? document.getElementById('tx-id').value : '';
    if (txIdStr) {
        const tx = app.data.transactions.find(t => t.id == txIdStr);
        if (tx && tx.date) {
            const isCashback = tx.tags && tx.tags.includes('#hoan_tien');
            const lockDays = isCashback ? 1 : 3;

            const diffDays = (new Date().getTime() - new Date(tx.date).getTime()) / (1000 * 3600 * 24);
            if (diffDays > lockDays) is3DaysOld = true;
        }
    }

    if (origVal) {
        const diff = getEditDistance(origVal, currentVal);

        // CHỈ CHẶN KHI: Đã quá 3 ngày VÀ sửa quá 6 ký tự
        if (is3DaysOld && diff > 6) {
            errorEl.style.display = 'block';
            errorEl.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> Vượt giới hạn sửa 6 ký tự (${typeName})!`;
            if (txSubmitBtn) { txSubmitBtn.disabled = true; txSubmitBtn.style.opacity = '0.5'; }
        } else {
            // Nếu chưa quá 3 ngày HOẶC sửa ít hơn 6 ký tự -> Cho phép lưu
            errorEl.style.display = 'none';

            // Các xử lý bật/tắt nút lưu và gán cờ khóa vĩnh viễn ở dưới vẫn giữ nguyên...
            const isOtherError = Array.from(document.querySelectorAll('#tx-ref-error, #tx-order-error')).some(el => el && el.style.display === 'block');
            if (!isOtherError && txSubmitBtn) {
                txSubmitBtn.disabled = false;
                txSubmitBtn.style.opacity = '1';
            }

            // LOGIC KHÓA VĨNH VIỄN
            if (is3DaysOld && diff > 0) {
                if (lockFlagEl) lockFlagEl.value = 'true';
            } else {
                if (lockFlagEl) lockFlagEl.value = 'false';
            }
        }
    }
};

// Định nghĩa hàm xử lý
function checkEcomLogic() {
    const placeEl = document.getElementById('tx-place');
    const brandEl = document.getElementById('tx-brand');

    // Logic kiểm tra sàn TMĐT
    if (placeEl && placeEl.value.toLowerCase().includes('shopee')) {
        // Code xử lý hiển thị thêm input của bạn ở đây...
        console.log("Phát hiện Shopee!");
    }
}

// Sự kiện lắng nghe
document.addEventListener('input', (e) => {
    // 1. Quét logic TMĐT
    if (e.target && (e.target.id === 'tx-place' || e.target.id === 'tx-brand')) {
        checkEcomLogic(); // FIX: Xóa 'app.logic.' đi, chỉ gọi tên hàm trực tiếp
    }

    // 2. Quét logic giới hạn sửa Mã GD
    if (e.target && e.target.id === 'tx-ref') {
        handleEditLimit(e, 'tx-original-ref', 'tx-ref-error', 'tx-fully-locked-flag', 'Mã GD');
    }

    // 3. Quét logic giới hạn sửa Mã Đơn
    if (e.target && e.target.id === 'tx-order-code') {
        handleEditLimit(e, 'tx-original-order-code', 'tx-order-error', 'tx-order-fully-locked-flag', 'Mã Đơn');
    }
});

// HÀM MỚI: Kiểm tra văn bản có khớp với ngôn ngữ đích không bằng Regex
function isTargetLanguage(text, targetLang) {
    // Xóa khoảng trắng và dấu câu để kiểm tra chính xác ký tự
    let cleanText = text.replace(/[\s\.,!\?\'\"\(\)\[\]\{\}-]/g, "");

    if (targetLang === "Tiếng Việt") {
        // Regex nhận diện chữ cái tiếng Việt (có dấu và không dấu)
        const vnRegex = /^[a-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỮỰỲỴÝỶỸửữựỳỵỷỹ]+$/;
        return vnRegex.test(cleanText);
    }
    else if (targetLang === "Tiếng Anh") {
        // Regex nhận diện chữ cái Latinh cơ bản (Tiếng Anh)
        const enRegex = /^[a-zA-Z]+$/;
        return enRegex.test(cleanText);
    }

    // Nếu là ngôn ngữ khác (Tiếng Nhật, v.v.) có thể mở rộng sau, tạm thời false để AI tự xử lý
    return false;
}
// ==========================================================
// FIX TRẠNG THÁI KHÓA CUỘN MOBILE BỊ SÓT
// ==========================================================
(() => {
    const clearStaleMobileScrollLock = () => {
        if (window.innerWidth > 768) return;

        const sidebar = document.getElementById('sidebar');
        const backdrop = document.getElementById('mobile-backdrop');

        const isMenuOpen =
            sidebar?.classList.contains('active') === true;

        document.body.classList.toggle(
            'mobile-menu-open',
            isMenuOpen
        );

        if (!isMenuOpen && backdrop) {
            backdrop.classList.remove('active');
            backdrop.setAttribute('aria-hidden', 'true');
        }
    };

    document.addEventListener(
        'DOMContentLoaded',
        clearStaleMobileScrollLock
    );

    window.addEventListener(
        'pageshow',
        clearStaleMobileScrollLock
    );

    window.addEventListener('orientationchange', () => {
        setTimeout(clearStaleMobileScrollLock, 150);
    });
})();